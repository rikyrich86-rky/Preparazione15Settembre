package it.lupisquad.preparazione

import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class StatsActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); render() }
    private fun render(){ Ui.screen(this,"Le tue statistiche","Diario") { body ->
        val all=PlanRepository.all(this)
        val done=all.count { PlanStore.status(this,it)==EventStatus.DONE }
        val skipped=all.count { PlanStore.status(this,it)==EventStatus.SKIPPED }
        val pending=all.size-done-skipped
        val pct=if(all.isEmpty()) 0 else done*100/all.size
        val top=Ui.card(this,Ui.ORANGE,16); top.addView(Ui.text(this,"$pct% completato",28f,Ui.ORANGE,true),Ui.lpMatch()); top.addView(Ui.text(this,"$done attività completate su ${all.size}",14f,Ui.MUTED),Ui.lpMatch()); Ui.add(body,top,bottom=12)
        val row=Ui.horizontal(this)
        fun stat(v:String,l:String,color:Int):LinearLayout{ val c=Ui.card(this,null,12); c.addView(Ui.text(this,v,23f,color,true),Ui.lpMatch()); c.addView(Ui.text(this,l,12f,Ui.MUTED),Ui.lpMatch()); return c }
        row.addView(stat(done.toString(),"Fatte",Ui.GREEN),Ui.lpWeight(1f)); row.addView(stat(pending.toString(),"Da fare",Ui.ORANGE),Ui.lpWeight(1f)); row.addView(stat(skipped.toString(),"Saltate",Ui.RED),Ui.lpWeight(1f)); Ui.add(body,row,bottom=14)
        Ui.add(body,Ui.text(this,"PER GIORNO",18f,Ui.TEXT,true),bottom=8)
        (Plan.startDate..Plan.targetDate).forEach { d ->
            val ev=PlanRepository.forDate(this,d); val dc=ev.count{PlanStore.status(this,it)==EventStatus.DONE}; val c=Ui.card(this,null,10); c.addView(Ui.text(this,"$d   $dc/${ev.size}",15f,Ui.TEXT,true),Ui.lpMatch()); Ui.add(body,c,bottom=6)
        }
    } }
}

private operator fun java.time.LocalDate.rangeTo(other:java.time.LocalDate):Iterable<java.time.LocalDate> = object:Iterable<java.time.LocalDate>{
    override fun iterator():Iterator<java.time.LocalDate> = generateSequence(this@rangeTo){ if(it<other) it.plusDays(1) else null }.iterator()
}
