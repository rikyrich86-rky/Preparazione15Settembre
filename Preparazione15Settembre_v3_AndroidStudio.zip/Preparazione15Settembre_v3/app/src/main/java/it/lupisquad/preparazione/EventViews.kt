package it.lupisquad.preparazione

import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

object EventViews {
    fun row(a:AppCompatActivity, event:PlanEvent, refresh:()->Unit):LinearLayout {
        val status=PlanStore.status(a,event)
        val card=Ui.card(a, if(status==EventStatus.PENDING) Ui.BORDER else null, 12)
        val main=Ui.horizontal(a)

        val left=Ui.vertical(a)
        val titleRow=Ui.horizontal(a)
        titleRow.addView(Ui.text(a,Ui.statusSymbol(status),22f,Ui.TEXT,true),LinearLayout.LayoutParams(Ui.dp(a,34),-2))
        titleRow.addView(Ui.text(a,Ui.iconFor(event.type),19f),LinearLayout.LayoutParams(Ui.dp(a,34),-2))
        titleRow.addView(Ui.text(a,event.title,16f,Ui.TEXT,true),LinearLayout.LayoutParams(0,-2,1f))
        left.addView(titleRow,Ui.lpMatch())
        val body=PlanStore.actual(a,event).ifBlank { event.body }
        left.addView(Ui.text(a,"${PlanStore.start(a,event)} · $body",12.5f,Ui.MUTED).apply { setPadding(Ui.dp(a,68),Ui.dp(a,5),Ui.dp(a,8),0) },Ui.lpMatch())
        main.addView(left,LinearLayout.LayoutParams(0,-2,1f))

        val actions=Ui.horizontal(a).apply { gravity=Gravity.CENTER }
        fun action(symbol:String,color:Int,run:()->Unit)=Ui.button(a,symbol,color,Color.WHITE).apply {
            minWidth=0; minimumWidth=0; setPadding(Ui.dp(a,7),Ui.dp(a,7),Ui.dp(a,7),Ui.dp(a,7)); setOnClickListener { run() }
        }
        actions.addView(action("✔️",Ui.GREEN){ PlanStore.setStatus(a,event,EventStatus.DONE); AlarmScheduler.scheduleAll(a); refresh() })
        actions.addView(action("○",Ui.CARD2){ PlanStore.setStatus(a,event,EventStatus.PENDING); AlarmScheduler.scheduleAll(a); refresh() })
        actions.addView(action("❌",Ui.RED){ PlanStore.setStatus(a,event,EventStatus.SKIPPED); AlarmScheduler.scheduleAll(a); refresh() })
        actions.addView(action("✍🏽",Ui.CARD2){ a.startActivity(Intent(a,EditEventActivity::class.java).putExtra("event_id",event.id)) })
        main.addView(actions,LinearLayout.LayoutParams(-2,-2))

        card.addView(main,Ui.lpMatch())
        card.setOnClickListener { a.startActivity(Intent(a,DetailActivity::class.java).putExtra("event_id",event.id)) }
        return card
    }
}
