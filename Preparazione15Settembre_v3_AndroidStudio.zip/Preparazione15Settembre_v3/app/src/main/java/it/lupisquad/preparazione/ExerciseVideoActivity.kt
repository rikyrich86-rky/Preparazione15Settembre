package it.lupisquad.preparazione

import android.net.Uri
import android.os.Bundle
import android.widget.MediaController
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class ExerciseVideoActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState)
        val key=intent.getStringExtra("video_key") ?: "mobility"; val title=intent.getStringExtra("title") ?: "Esercizio"
        Ui.screen(this,title,"Video") { body ->
            val vv=VideoView(this); vv.layoutParams=Ui.lpMatch().apply { height=Ui.dp(this@ExerciseVideoActivity,330) }
            val resId=resources.getIdentifier(key,"raw",packageName)
            if(resId!=0){ vv.setVideoURI(Uri.parse("android.resource://$packageName/$resId")); vv.setMediaController(MediaController(this).apply{setAnchorView(vv)}); vv.setOnPreparedListener { it.isLooping=true; vv.start() } }
            Ui.add(body,vv,bottom=12)
            Ui.add(body,Ui.text(this,"Osserva il movimento completo e mantieni un'esecuzione controllata. Interrompi se avverti dolore.",14f,Ui.MUTED),bottom=20)
        }
    }
}
