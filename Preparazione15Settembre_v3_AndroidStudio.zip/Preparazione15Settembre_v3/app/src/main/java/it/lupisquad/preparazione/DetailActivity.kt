package it.lupisquad.preparazione

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class DetailActivity:AppCompatActivity(){
    private var eventId:Int=-1
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); eventId=intent.getIntExtra("event_id",-1); render() }
    override fun onResume(){ super.onResume(); render() }
    private fun render(){ val e=PlanRepository.byId(this,eventId) ?: run { finish(); return }
        Ui.screen(this,e.title,"Home") { body ->
            val c=Ui.card(this,Ui.ORANGE,16)
            c.addView(Ui.text(this,"${Ui.iconFor(e.type)}  ${Ui.statusSymbol(PlanStore.status(this,e))} ${e.title}",24f,Ui.TEXT,true),Ui.lpMatch())
            c.addView(Ui.text(this,"${PlanStore.start(this,e)} — ${PlanStore.end(this,e)}",15f,Ui.ORANGE,true),Ui.lpMatch())
            c.addView(Ui.spacer(this,10)); c.addView(Ui.text(this,PlanStore.actual(this,e).ifBlank{e.body},17f,Ui.TEXT),Ui.lpMatch())
            Ui.add(body,c,bottom=14)
            if(e.exercises.isNotEmpty()){
                Ui.add(body,Ui.text(this,"ESERCIZI",18f,Ui.TEXT,true),bottom=8)
                e.exercises.forEachIndexed { i,ex ->
                    val x=Ui.card(this,null,12); x.addView(Ui.text(this,"${i+1}. ${ex.name}",17f,Ui.TEXT,true),Ui.lpMatch()); x.addView(Ui.text(this,"${ex.prescription}${if(ex.rest.isNotBlank()) " · ${ex.rest}" else ""}",13f,Ui.MUTED),Ui.lpMatch())
                    val play=Ui.button(this,"▶  Guarda video ${ex.name}"); play.setOnClickListener { startActivity(Intent(this,ExerciseVideoActivity::class.java).putExtra("video_key",ex.videoKey).putExtra("title",ex.name)) }; x.addView(play,Ui.lpMatch()); Ui.add(body,x,bottom=8)
                }
            }
            val edit=Ui.button(this,"✍🏽  Modifica attività",Ui.CARD2,Ui.TEXT); edit.setOnClickListener { startActivity(Intent(this,EditEventActivity::class.java).putExtra("event_id",e.id)) }; Ui.add(body,edit,top=6,bottom=8)
            val done=Ui.button(this,"✔️  Segna come completato",Ui.GREEN,android.graphics.Color.WHITE); done.setOnClickListener { PlanStore.setStatus(this,e,EventStatus.DONE); AlarmScheduler.scheduleAll(this); render() }; Ui.add(body,done,bottom=16)
            val note=PlanStore.note(this,e); if(note.isNotBlank()){ Ui.add(body,Ui.text(this,"Nota: $note",14f,Ui.MUTED),bottom=12) }
        }
    }
}
