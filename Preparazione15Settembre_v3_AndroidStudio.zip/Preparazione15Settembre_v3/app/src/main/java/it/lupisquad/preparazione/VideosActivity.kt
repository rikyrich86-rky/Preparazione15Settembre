package it.lupisquad.preparazione

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class VideosActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); render() }
    private fun render(){ Ui.screen(this,"Video esercizi","Video") { body ->
        Ui.add(body,Ui.text(this,"Tutorial specifici degli esercizi presenti nel programma.",14f,Ui.MUTED),bottom=12)
        val videos=listOf(
            Triple("Piegamenti","Tecnica e ritmo","pushup"),
            Triple("Squat","Controllo di anche e ginocchia","squat"),
            Triple("Affondi","Passo, discesa e ritorno","lunge"),
            Triple("Plank","Allineamento e tenuta","plank"),
            Triple("Crunch","Flessione controllata del tronco","crunch"),
            Triple("Mountain climber","Alternanza delle ginocchia","mountain"),
            Triple("Cardio","Camminata veloce / cyclette","cardio"),
            Triple("Mobilità","Risveglio e mobilità articolare","mobility")
        )
        videos.forEach { (name,sub,key) ->
            val c=Ui.card(this,null,12); c.addView(Ui.text(this,"▶  $name",17f,Ui.TEXT,true),Ui.lpMatch()); c.addView(Ui.text(this,sub,13f,Ui.MUTED),Ui.lpMatch()); c.setOnClickListener { startActivity(Intent(this,ExerciseVideoActivity::class.java).putExtra("video_key",key).putExtra("title",name)) }; Ui.add(body,c,bottom=8)
        }
    } }
}
