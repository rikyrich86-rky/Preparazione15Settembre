package it.lupisquad.preparazione

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object Ui {
    val BG = Color.rgb(5,9,12)
    val CARD = Color.rgb(11,21,28)
    val CARD2 = Color.rgb(15,28,36)
    val ORANGE = Color.rgb(255,100,26)
    val GREEN = Color.rgb(24,190,110)
    val RED = Color.rgb(225,63,63)
    val TEXT = Color.WHITE
    val MUTED = Color.rgb(166,179,188)
    val BORDER = Color.rgb(31,51,62)

    fun dp(c:Context,v:Int)=(v*c.resources.displayMetrics.density).toInt()
    fun bg(color:Int, radius:Int=18, stroke:Int?=null):GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius=radius.toFloat(); if(stroke!=null) setStroke(1,stroke)
    }
    fun vertical(c:Context, pad:Int=0)=LinearLayout(c).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(c,pad),dp(c,pad),dp(c,pad),dp(c,pad)) }
    fun horizontal(c:Context)=LinearLayout(c).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
    fun text(c:Context, value:String, size:Float=16f, color:Int=TEXT, bold:Boolean=false)=TextView(c).apply {
        text=value; textSize=size; setTextColor(color); if(bold) setTypeface(typeface,Typeface.BOLD); includeFontPadding=false
    }
    fun button(c:Context, value:String, color:Int=ORANGE, textColor:Int=Color.BLACK)=Button(c).apply {
        text=value; setTextColor(textColor); textSize=14f; isAllCaps=false; background=bg(color,16); minHeight=0; minimumHeight=0; setPadding(dp(c,14),dp(c,10),dp(c,14),dp(c,10))
    }
    fun spacer(c:Context,h:Int)=Space(c).apply { layoutParams=LinearLayout.LayoutParams(1,dp(c,h)) }
    fun card(c:Context, stroke:Int?=BORDER, pad:Int=14)=vertical(c,pad).apply { background=bg(CARD,20,stroke) }
    fun lpMatch()=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT)
    fun lpWeight(w:Float)=LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,w)
    fun add(container:LinearLayout, view:View, top:Int=0, bottom:Int=0){ container.addView(view,lpMatch().apply { topMargin=dp(container.context,top); bottomMargin=dp(container.context,bottom) }) }

    fun iconFor(type:EventType)=when(type){
        EventType.MEAL->"🍽️"; EventType.WORKOUT->"🏋️"; EventType.MOBILITY->"🧘"; EventType.SUPPLEMENT->"💊"; EventType.SLEEP->"🌙"; EventType.OTHER->"•"
    }
    fun statusSymbol(status:EventStatus)=when(status){ EventStatus.DONE->"✔️"; EventStatus.PENDING->"○"; EventStatus.SKIPPED->"❌" }

    fun screen(activity:AppCompatActivity, title:String, active:String, bodyBuilder:(LinearLayout)->Unit){
        val root=vertical(activity).apply { setBackgroundColor(BG) }
        val scroll=ScrollView(activity).apply { isFillViewport=true }
        val body=vertical(activity,18)
        add(body,text(activity,title,28f,TEXT,true),bottom=16)
        bodyBuilder(body)
        scroll.addView(body)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(bottomNav(activity,active),LinearLayout.LayoutParams(-1,dp(activity,70)))
        activity.setContentView(root)
    }

    fun bottomNav(a:AppCompatActivity, active:String):View {
        val bar=horizontal(a).apply { setPadding(dp(a,8),dp(a,8),dp(a,8),dp(a,8)); background=bg(Color.rgb(7,14,19),0,BORDER) }
        val items=listOf("Home" to MainActivity::class.java,"Programma" to ProgramActivity::class.java,"Video" to VideosActivity::class.java,"Diario" to DiaryActivity::class.java,"Altro" to MoreActivity::class.java)
        items.forEach { (label,cls) ->
            val t=text(a,label,12f,if(label==active) ORANGE else MUTED,label==active).apply { gravity=Gravity.CENTER; setPadding(2,8,2,8); setOnClickListener { if(a::class.java!=cls){ a.startActivity(Intent(a,cls)); a.overridePendingTransition(0,0); a.finish() } } }
            bar.addView(t,LinearLayout.LayoutParams(0,-1,1f))
        }
        return bar
    }

    fun daySelector(a:AppCompatActivity,date:LocalDate,onChange:(LocalDate)->Unit):View {
        val row=horizontal(a).apply { background=bg(CARD2,18,BORDER); setPadding(dp(a,12),dp(a,8),dp(a,12),dp(a,8)) }
        val prev=button(a,"‹",CARD2,TEXT); val next=button(a,"›",CARD2,TEXT)
        val fmt=DateTimeFormatter.ofPattern("EEEE d MMMM",Locale.ITALIAN)
        val middle=text(a,date.format(fmt).replaceFirstChar{it.uppercase()},17f,TEXT,true).apply { gravity=Gravity.CENTER; setPadding(8,12,8,12) }
        prev.setOnClickListener{ onChange(date.minusDays(1)) }; next.setOnClickListener{ onChange(date.plusDays(1)) }
        row.addView(prev,LinearLayout.LayoutParams(dp(a,48),-2)); row.addView(middle,LinearLayout.LayoutParams(0,-2,1f)); row.addView(next,LinearLayout.LayoutParams(dp(a,48),-2))
        return row
    }
}
