package it.lupisquad.preparazione

import java.time.LocalDate
import java.time.LocalTime

object Plan {
    val startDate: LocalDate = LocalDate.of(2026, 9, 6)
    val targetDate: LocalDate = LocalDate.of(2026, 9, 15)

    private var id = 1000
    private fun e(d:String, s:String, e:String, title:String, body:String, type:EventType, exercises:List<Exercise> = emptyList()) =
        PlanEvent(id++, LocalDate.parse(d), LocalTime.parse(s), LocalTime.parse(e), title, body, type, exercises)

    private val fullBody = listOf(
        Exercise("Piegamenti", "4 × 12-15", "Recupero 45 s", "pushup"),
        Exercise("Squat", "4 × 15", "Recupero 45 s", "squat"),
        Exercise("Affondi", "4 × 12 per gamba", "Recupero 45 s", "lunge"),
        Exercise("Plank", "3 × 45 s", "Recupero 45 s", "plank")
    )
    private val coreCardio = listOf(
        Exercise("Crunch", "3 × 20", "Recupero 30 s", "crunch"),
        Exercise("Mountain climber", "3 × 30", "Recupero 30 s", "mountain"),
        Exercise("Plank", "3 × 45 s", "Recupero 45 s", "plank")
    )
    private val light = listOf(
        Exercise("Piegamenti", "3 × 12", "Recupero 45 s", "pushup"),
        Exercise("Mobilità", "10 min", "Movimenti controllati", "mobility")
    )

    val events: List<PlanEvent> = buildList {
        fun day(d:String, breakfast:String, snack1:String, lunch:String, snack2:String, dinner:String, workoutTime:String?, workoutBody:String?, exercises:List<Exercise> = emptyList()) {
            add(e(d,"08:30","08:45","Colazione",breakfast,EventType.MEAL))
            add(e(d,"11:00","11:10","Spuntino",snack1,EventType.MEAL))
            add(e(d,"13:30","14:00","Pranzo",lunch,EventType.MEAL))
            add(e(d,"16:30","16:40","Spuntino",snack2,EventType.MEAL))
            if (workoutTime != null && workoutBody != null) {
                val start=LocalTime.parse(workoutTime)
                add(e(d, start.minusMinutes(45).toString(), start.minusMinutes(40).toString(), "L-Citrullina / L-Arginina", "Promemoria pre-allenamento. Segui esclusivamente dose e indicazioni riportate in etichetta o concordate con un professionista.", EventType.SUPPLEMENT))
                add(e(d,workoutTime,start.plusMinutes(35).toString(),"Allenamento",workoutBody,EventType.WORKOUT,exercises))
            }
            add(e(d,"20:30","21:00","Cena",dinner,EventType.MEAL))
            add(e(d,"22:30","22:35","Zinco + Magnesio","Promemoria serale. Segui dose e indicazioni riportate in etichetta o concordate con medico/farmacista.",EventType.SUPPLEMENT))
        }

        day("2026-09-06","Yogurt greco 0% 200 g + 30 g avena + frutti di bosco.","1 mela + 5 mandorle.","Riso basmati 70 g + pollo 150 g + zucchine.","Yogurt greco 0% oppure fesa di tacchino 100 g.","Orata/spigola 200 g + finocchi e cetrioli.","10:00","Full body · circa 35 min",fullBody)
        day("2026-09-07","3 albumi + 1 uovo + 2 fette pane di segale.","Banana piccola + 5 mandorle.","Pasta integrale 70 g + tonno al naturale + pomodorini.","Yogurt greco 0%.","Tacchino 180 g + asparagi.","18:00","Cardio moderato · 30 min",listOf(Exercise("Camminata veloce / cyclette","30 min","Ritmo regolare","cardio")))
        day("2026-09-08","Yogurt greco 0% + frutti rossi.","1 mela.","Quinoa/riso integrale 70 g + pollo 150 g + verdure.","Fesa di tacchino 80 g.","Salmone 180 g + cetrioli e finocchi.","18:00","Full body · circa 35 min",fullBody)
        day("2026-09-09","3 albumi + 1 uovo + 2 gallette di riso.","1 pera + 3 noci.","Patate 200 g + merluzzo 200 g + zucchine.","Yogurt greco 0%.","Pollo 180 g + asparagi/spinaci.","18:00","Core + cardio · circa 30 min",coreCardio)
        day("2026-09-10","Yogurt greco 0% + 30 g avena + noci.","1 mela.","Riso basmati 70 g + tacchino 150 g + finocchi.","Fesa di tacchino 80 g.","Orata 200 g + cetrioli + zucchine.","18:00","Full body · circa 35 min",fullBody)
        day("2026-09-11","3 albumi + 1 uovo + 2 fette pane di segale.","1 banana.","Couscous 70 g + tonno + zucchine.","Yogurt greco 0%.","Vitello magro 180 g + asparagi + insalata.","18:00","Cardio moderato · 30 min",listOf(Exercise("Camminata veloce / cyclette","30 min","Ritmo regolare","cardio")))
        day("2026-09-12","Yogurt greco 0% + frutti di bosco + mandorle.","1 mela.","Riso basmati 60 g + pollo 150 g + finocchi.","Fesa di tacchino 80 g.","Pizza Margherita o Marinara semplice.","10:00","Seduta leggera · circa 25 min",light)
        day("2026-09-13","3 albumi + 1 uovo + 2 gallette di riso.","1 pera.","Pollo 180 g + finocchi/cetrioli.","Yogurt greco 0%.","Merluzzo/spigola 200 g + zucchine.",null,null)
        day("2026-09-14","Yogurt greco 0% + 30 g avena.","1 mela.","Riso basmati 50 g + tacchino 150 g + asparagi.","Fesa di tacchino 80 g.","Pesce bianco 200 g oppure pollo + finocchi.",null,null)
        day("2026-09-15","Yogurt greco 0% + pochi frutti di bosco.","Mandorle.","Riso basmati 50 g + pollo 150 g + zucchine.","1 mela oppure yogurt proteico.","Pasto leggero e idratazione regolare.",null,null)

        for (d in startDate..targetDate) {
            add(e(d.toString(),"07:45","08:00","Mobilità e risveglio","Movimenti dolci, respirazione regolare, 10-15 minuti.",EventType.MOBILITY,listOf(Exercise("Mobilità","10-15 min","Movimento controllato","mobility"))))
        }
    }.sortedWith(compareBy({it.date},{it.start}))

    private operator fun LocalDate.rangeTo(other: LocalDate): Iterable<LocalDate> = object : Iterable<LocalDate> {
        override fun iterator(): Iterator<LocalDate> = generateSequence(this@rangeTo) { if (it < other) it.plusDays(1) else null }.iterator()
    }
}
