package it.lupisquad.preparazione

import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate

class DiaryActivity:AppCompatActivity(){
    private var date=LocalDate.now().let { when { it<Plan.startDate->Plan.startDate; it>Plan.targetDate->Plan.targetDate; else->it } }
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); render() }
    override fun onResume(){ super.onResume(); render() }
    private fun render(){ Ui.screen(this,"Diario","Diario") { body ->
        Ui.add(body,Ui.daySelector(this,date){ date=when { it<Plan.startDate->Plan.startDate; it>Plan.targetDate->Plan.targetDate; else->it }; render() },bottom=12)
        val events=PlanRepository.forDate(this,date)
        val done=events.count { PlanStore.status(this,it)==EventStatus.DONE }; val skipped=events.count { PlanStore.status(this,it)==EventStatus.SKIPPED }
        val summary=Ui.card(this,Ui.ORANGE,14); summary.addView(Ui.text(this,"$done/${events.size} completate",22f,Ui.TEXT,true),Ui.lpMatch()); summary.addView(Ui.text(this,"$skipped saltate · ${events.size-done-skipped} ancora da fare",13f,Ui.MUTED),Ui.lpMatch()); Ui.add(body,summary,bottom=12)
        events.forEach { Ui.add(body,EventViews.row(this,it){ render() },bottom=8) }
        val stats=Ui.button(this,"📊  Vedi statistiche",Ui.CARD2,Ui.TEXT); stats.setOnClickListener { startActivity(android.content.Intent(this,StatsActivity::class.java)) }; Ui.add(body,stats,top=8,bottom=10)
        val note=EditText(this).apply { hint="Nota personale della giornata"; setText(PlanStore.dayNote(this@DiaryActivity,date)); setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED); minLines=4; background=Ui.bg(Ui.CARD2,16,Ui.BORDER); setPadding(Ui.dp(this@DiaryActivity,12),Ui.dp(this@DiaryActivity,12),Ui.dp(this@DiaryActivity,12),Ui.dp(this@DiaryActivity,12)) }
        Ui.add(body,note,top=8,bottom=8)
        val save=Ui.button(this,"Salva nota"); save.setOnClickListener { PlanStore.setDayNote(this,date,note.text.toString()) }; Ui.add(body,save,bottom=20)
    } }
}
