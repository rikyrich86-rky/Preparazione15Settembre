# Risveglia il tuo fisico — Android v3.0

App Android nativa (Kotlin, minSdk 26, targetSdk 35) per il programma 6–15 settembre 2026.

## Pagine e funzioni
- Home: countdown al 15 settembre, progressione, selettore giorno, prossima attività, programma giornaliero con stato `✔️ ○ ❌ ✍🏽`.
- Programma: cambia giorno, aggiungi attività, modifica, rimuovi con pressione prolungata.
- Dettaglio attività: mostra contenuto del pasto / integratore o elenco esercizi dell'allenamento.
- Modifica: ora inizio, ora fine, attività realmente svolta / cibo realmente mangiato, note.
- Video: tutorial specifici per piegamenti, squat, affondi, plank, crunch, mountain climber, cardio e mobilità. Gli stessi video sono richiamati dal dettaglio dell'allenamento.
- Diario: riepilogo giornaliero, stati, note personali e accesso alle statistiche.
- Statistiche: completate / da fare / saltate e riepilogo per giorno.
- Altro: riprogrammazione notifiche, batteria/background Samsung, info e reset dati.
- Notifiche: AlarmManager; ogni modifica dell'orario riprogramma gli avvisi. Gli eventi completati o saltati non vengono notificati.

## Persistenza
Stati, orari, note, attività realmente svolte e attività personalizzate sono salvati localmente con SharedPreferences.

## Build
Il progetto è compatibile con Android Studio e con il workflow GitHub Actions già usato per le versioni precedenti.
AGP 8.8.2, Kotlin 2.1.10, Java 17, compileSdk 35.
