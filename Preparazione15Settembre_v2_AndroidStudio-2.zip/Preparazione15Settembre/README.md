# Preparazione 15 Settembre — Android

App Android nativa (Kotlin) pensata per Samsung Galaxy S26 Ultra.

## Cosa fa
- programma dal 6 al 15 settembre 2026;
- notifiche locali anche a schermo spento tramite AlarmManager;
- riprogrammazione automatica dopo riavvio del telefono;
- schermata con prossimo impegno e programma completo;
- clip video offline integrate per full body, cardio, core e mobilità;
- promemoria L-Citrullina/L-Arginina pre-allenamento e nei giorni di riposo;
- promemoria serale Zinco + Magnesio.

## Orari scelti dove la bozza non indicava un'ora precisa
- spuntino mattina 11:00
- pranzo 13:30
- spuntino pomeriggio 16:30
- cena 20:30
- allenamento mattutino 10:00
- allenamento pomeridiano 18:00
- L-Citrullina/L-Arginina: 45 minuti prima dell'allenamento; nei giorni senza allenamento 08:15
- Zinco + Magnesio: 30 minuti prima dell'orario di sonno

Gli orari sono centralizzati in `Plan.kt` e si possono modificare facilmente.

## Installazione / compilazione
1. Apri la cartella del progetto con Android Studio.
2. Lascia completare Gradle Sync.
3. Collega il Samsung via USB con Debug USB attivo oppure usa Wireless debugging.
4. Premi Run per installare l'app.
5. Al primo avvio autorizza notifiche e “Sveglie e promemoria”.
6. Sul Samsung apri dall'app “Impostazioni batteria Samsung” e assicurati che l'app non sia messa tra quelle in sospensione profonda.

## Nota sugli integratori
L'app non imposta dosaggi: mostra soltanto il promemoria richiesto e rimanda a etichetta/indicazione di medico o farmacista, perché dosi e compatibilità dipendono dal prodotto e dalla situazione individuale.
