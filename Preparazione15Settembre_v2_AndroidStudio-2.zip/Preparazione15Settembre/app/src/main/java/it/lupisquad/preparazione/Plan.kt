package it.lupisquad.preparazione

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

data class PlanEvent(val id:Int, val date:LocalDate, val time:LocalTime, val title:String, val body:String, val video:String?=null)

object Plan {
    private var nextId = 1000
    private fun e(d:String,t:String,title:String,body:String,video:String?=null)=PlanEvent(nextId++,LocalDate.parse(d),LocalTime.parse(t),title,body,video)
    val events: List<PlanEvent> = buildList {
        fun day(d:String, wake:String, breakfast:String, snack1:String, lunch:String, snack2:String, dinner:String, bed:String,
                morning:String, workoutTime:String?, workout:String?, video:String?, rest:Boolean=false) {
            add(e(d,wake,"Sveglia + acqua","Bevi subito 1 bicchiere abbondante d'acqua."))
            add(e(d, LocalTime.parse(wake).plusMinutes(10).toString(), "Risveglio muscolare", morning))
            add(e(d, LocalTime.parse(wake).plusMinutes(30).toString(), "Colazione", breakfast))
            add(e(d,"11:00","Spuntino",snack1))
            add(e(d,"13:30","Pranzo",lunch))
            add(e(d,"16:30","Spuntino",snack2))
            if (workoutTime != null && workout != null) {
                val wt=LocalTime.parse(workoutTime)
                add(e(d,wt.minusMinutes(45).toString(),"L-Citrullina / L-Arginina","Promemoria pre-allenamento: assumi solo la dose prevista dall'etichetta o concordata con un professionista."))
                add(e(d,workoutTime,"Allenamento",workout,video))
            } else {
                add(e(d,"08:15","L-Citrullina / L-Arginina","Giorno di riposo: promemoria mattutino a stomaco vuoto. Dose secondo etichetta/indicazione professionale."))
            }
            add(e(d,"20:30","Cena",dinner))
            val bt=LocalTime.parse(bed)
            add(e(d,bt.minusMinutes(30).toString(),"Zinco + Magnesio","Promemoria serale prima di coricarti. Dose secondo etichetta/indicazione di medico o farmacista."))
            add(e(d,bed,"Nanna","Vai a dormire. Bevi 1 bicchiere d'acqua; priorità al recupero."))
        }
        day("2026-09-06","08:00","Yogurt greco 0% 200 g + frutti di bosco + 30 g noci. Acqua 300 ml.","1 mela + acqua 300 ml.","Riso basmati 70 g + pollo 150 g + zucchine. Acqua 500 ml.","Proteine isolate oppure fesa di tacchino 100 g + acqua 300 ml.","Orata/spigola 200 g + finocchi e cetrioli. Acqua 500 ml.","23:00","10 min stretching dinamico: braccia, torsioni, gatto-mucca.","10:00","4×12-15 push-up · 4×15 squat · 4×12 affondi/gamba · 3×45 s plank.","full_body")
        day("2026-09-07","07:30","3 albumi + 1 uovo + 2 fette pane di segale. Acqua 300 ml.","Banana piccola + 5 mandorle. Acqua 250 ml.","Pasta integrale 70 g + tonno al naturale 112 g + pomodorini. Acqua 500 ml.","Yogurt greco 0% + acqua 250 ml.","Tacchino 180 g + asparagi. Acqua 500 ml.","23:00","5 min mobilità articolare + Kegel leggeri.","18:00","30 min camminata veloce o cyclette a ritmo costante.","cardio")
        day("2026-09-08","07:30","Pancake proteico oppure yogurt greco 0% + frutti rossi. Acqua 300 ml.","1 mela + acqua 250 ml.","Quinoa/riso integrale 70 g + pollo 150 g + zucchine/melanzane. Acqua 500 ml.","Fesa di tacchino 80 g + acqua 300 ml.","Salmone 180 g + cetrioli e finocchi. Acqua 500 ml.","23:00","Stretching e mobilità per la schiena.","18:00","4×15 push-up · 4×15 squat · 4×12 affondi · 3×1 min plank + Kegel leggeri.","full_body")
        day("2026-09-09","07:30","3 albumi + 1 uovo + 2 gallette di riso. Acqua 300 ml.","1 pera + 3 noci. Acqua 250 ml.","Patate 200 g + merluzzo/baccalà 200 g + zucchine. Acqua 500 ml.","Yogurt greco 0% + acqua 250 ml.","Pollo 180 g + asparagi/spinaci. Acqua 500 ml.","23:00","10 min mobilità arti inferiori + Kegel leggeri.","18:00","25 min cyclette/camminata + 3×20 crunch + 3×15 leg raise.","core_cardio")
        day("2026-09-10","07:30","Yogurt greco 0% + 30 g avena + noci. Acqua 300 ml.","1 mela + acqua 250 ml.","Riso basmati 70 g + tacchino 150 g + finocchi. Acqua 500 ml.","Fesa di tacchino 80 g + acqua 300 ml.","Orata 200 g + cetrioli + zucchine. Acqua 500 ml.","23:00","Stretching catena posteriore.","18:00","4×15 push-up · 4×15 squat · 4×12 affondi · 3×45 s plank + Kegel leggeri.","full_body")
        day("2026-09-11","07:30","3 albumi + 1 uovo + 2 fette pane di segale. Acqua 300 ml.","1 banana + acqua 250 ml.","Couscous 70 g + tonno 112 g + zucchine. Acqua 500 ml.","Yogurt greco 0% + acqua 250 ml.","Vitello magro 180 g + asparagi + insalata. Acqua 500 ml.","23:00","Mobilizzazione dolce + Kegel leggeri.","18:00","30 min camminata ritmata/cyclette, senza fatica estrema.","cardio")
        day("2026-09-12","08:00","Yogurt greco 0% + frutti di bosco + mandorle. Acqua 300 ml.","1 mela + acqua 300 ml.","Riso basmati 60 g + pollo 150 g + finocchi. Acqua 500 ml.","Fesa di tacchino 80 g + acqua 300 ml.","Pizza Margherita o Marinara semplice + acqua 500 ml.","23:30","10 min stretching.","10:00","20 min cardio leggero + 3×12 push-up + Kegel leggeri.","light")
        day("2026-09-13","08:30","3 albumi + 1 uovo + 2 gallette di riso. Acqua 300 ml.","1 pera + acqua 300 ml.","Pollo 180 g + finocchi/cetrioli. Acqua 500 ml.","Yogurt greco 0% + acqua 300 ml.","Merluzzo/spigola 200 g + zucchine. Acqua 500 ml.","22:30","5 min respirazione profonda + Kegel leggeri. NO allenamento.",null,null,null,true)
        day("2026-09-14","07:30","Yogurt greco 0% + 30 g avena. Acqua 300 ml.","1 mela + acqua 250 ml.","Riso basmati 50 g + tacchino 150 g + asparagi. Acqua 500 ml.","Fesa di tacchino 80 g + acqua 250 ml.","Pesce bianco 200 g oppure pollo + finocchi. Acqua 500 ml.","22:30","Kegel leggerissimi. NO allenamento.",null,null,null,true)
        day("2026-09-15","08:00","Yogurt greco 0% + pochi frutti di bosco oppure fesa di tacchino + gallette. Acqua 300 ml.","Mandorle + acqua 300 ml.","Riso basmati 50 g + pollo 150 g + zucchine. Acqua 500 ml.","1 mela oppure yogurt proteico.","Serata: pasto leggero, idratazione regolare a piccoli sorsi.","23:00","Solo mobilità dolce e sensazione di leggerezza. Nessun allenamento.",null,null,null,true)
    }.sortedWith(compareBy({it.date},{it.time}))

    fun next(now:LocalDateTime=LocalDateTime.now()) = events.firstOrNull { LocalDateTime.of(it.date,it.time).isAfter(now) }
    fun today(d:LocalDate=LocalDate.now()) = events.filter { it.date==d }
}
