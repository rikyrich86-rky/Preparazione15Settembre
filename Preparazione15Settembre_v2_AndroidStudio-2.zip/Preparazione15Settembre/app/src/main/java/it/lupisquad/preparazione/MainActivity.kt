package it.lupisquad.preparazione

import android.Manifest
import android.app.AlarmManager
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        if(Build.VERSION.SDK_INT>=33 && ActivityCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),10)
        if(Build.VERSION.SDK_INT>=31){ val am=getSystemService(ALARM_SERVICE) as AlarmManager; if(!am.canScheduleExactAlarms()) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
        AlarmScheduler.scheduleAll(this)
        refresh()
        findViewById<Button>(R.id.btnSchedule).setOnClickListener{startActivity(Intent(this,ScheduleActivity::class.java))}
        findViewById<Button>(R.id.btnToday).setOnClickListener{startActivity(Intent(this,ScheduleActivity::class.java).putExtra("date",LocalDate.now().toString()))}
        findViewById<Button>(R.id.btnVideo).setOnClickListener{ val v=Plan.today().firstOrNull{it.video!=null}?.video ?: "mobility"; startActivity(Intent(this,VideoActivity::class.java).putExtra("video",v)) }
        findViewById<Button>(R.id.btnReschedule).setOnClickListener{AlarmScheduler.scheduleAll(this); Toast.makeText(this,"Notifiche aggiornate",Toast.LENGTH_SHORT).show()}
        findViewById<Button>(R.id.btnBattery).setOnClickListener{startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))}
    }
    override fun onResume(){super.onResume(); refresh()}
    private fun refresh(){
        val today=Plan.today(); val done=today.count{PlanStore.done(this,it)}
        findViewById<TextView>(R.id.txtToday).text=if(today.isEmpty()) "Oggi: recupero e costanza." else "OGGI · $done/${today.size} completati"
        val now=LocalDateTime.now(); val n=Plan.events.firstOrNull { !PlanStore.done(this,it) && LocalDateTime.of(it.date,PlanStore.time(this,it)).isAfter(now) }
        findViewById<TextView>(R.id.txtNext).text=if(n==null) "PROGRAMMA COMPLETATO 🎯" else "PROSSIMO OBIETTIVO\n${n.date.format(DateTimeFormatter.ofPattern("EEE d MMM",Locale.ITALIAN))} · ${PlanStore.time(this,n)}\n\n${n.title}\n${n.body}"
        val total=Plan.events.count{it.date<=LocalDate.now()}; val completed=Plan.events.count{it.date<=LocalDate.now() && PlanStore.done(this,it)}
        findViewById<ProgressBar>(R.id.progress).apply { max=if(total==0)1 else total; progress=completed }
        findViewById<TextView>(R.id.txtMotivation).text=when {
            completed==0 -> "Si parte. Un'azione alla volta."
            total>0 && completed>=total -> "Ottimo: giornata portata a casa."
            else -> "Continua così: la costanza oggi vale più della perfezione."
        }
    }
}
