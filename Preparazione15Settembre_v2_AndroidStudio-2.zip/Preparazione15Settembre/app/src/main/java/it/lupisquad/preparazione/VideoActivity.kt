package it.lupisquad.preparazione
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class VideoActivity:AppCompatActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_video)
 val key=intent.getStringExtra("video")?:"mobility"
 val map=mapOf("full_body" to R.raw.full_body,"cardio" to R.raw.cardio,"core_cardio" to R.raw.core_cardio,"light" to R.raw.light,"mobility" to R.raw.mobility)
 val notes=mapOf("full_body" to "Push-up · squat · affondi · plank. Movimento controllato; interrompi se compare dolore.","cardio" to "Camminata veloce/cyclette a ritmo facile-moderato.","core_cardio" to "Cardio + crunch + leg raise. Evita di inarcare la zona lombare.","light" to "Cardio leggero + push-up. Sessione di scarico.","mobility" to "Mobilità dolce e respirazione.")
 findViewById<TextView>(R.id.videoTitle).text="Clip esercizi"
 findViewById<TextView>(R.id.videoNotes).text=notes[key]
 val vv=findViewById<VideoView>(R.id.videoView); vv.setVideoURI(Uri.parse("android.resource://$packageName/${map[key]?:R.raw.mobility}")); vv.setMediaController(MediaController(this).also{it.setAnchorView(vv)}); vv.setOnPreparedListener{it.isLooping=true;vv.start()}
}}
