package it.lupisquad.preparazione

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDateTime
import java.time.ZoneId

object AlarmScheduler {
    fun scheduleAll(context: Context) {
        val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now=System.currentTimeMillis()
        for (ev in Plan.events) {
            val time=PlanStore.time(context, ev)
            val millis=LocalDateTime.of(ev.date,time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val i=Intent(context,AlarmReceiver::class.java).apply {
                putExtra("id",ev.id); putExtra("title",ev.title); putExtra("body",ev.body); putExtra("video",ev.video)
            }
            val pi=PendingIntent.getBroadcast(context,ev.id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.cancel(pi)
            if (millis <= now || PlanStore.done(context, ev)) continue
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi)
                else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi)
            } catch (_:SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi) }
        }
    }
}
