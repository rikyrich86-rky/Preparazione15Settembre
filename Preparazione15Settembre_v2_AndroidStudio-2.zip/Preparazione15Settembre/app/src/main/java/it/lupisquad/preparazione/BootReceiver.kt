package it.lupisquad.preparazione
import android.content.*
class BootReceiver:BroadcastReceiver(){ override fun onReceive(context:Context,intent:Intent){ AlarmScheduler.scheduleAll(context) } }
