package it.lupisquad.preparazione

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver: BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        val channel="plan_reminders"
        val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(channel,"Promemoria programma",NotificationManager.IMPORTANCE_HIGH))
        val open=Intent(context,MainActivity::class.java)
        val pi=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n=NotificationCompat.Builder(context,channel)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(intent.getStringExtra("title") ?: "Promemoria")
            .setContentText(intent.getStringExtra("body") ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(intent.getStringExtra("body") ?: ""))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build()
        nm.notify(intent.getIntExtra("id",1),n)
    }
}
