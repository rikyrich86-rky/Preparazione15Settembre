package it.lupisquad.preparazione

import android.content.Context
import java.time.LocalTime

object PlanStore {
    private const val PREFS = "plan_custom"
    fun time(context: Context, event: PlanEvent): LocalTime {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("time_${event.id}", null)
        return try { raw?.let { LocalTime.parse(it) } ?: event.time } catch (_: Exception) { event.time }
    }
    fun setTime(context: Context, event: PlanEvent, time: LocalTime) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("time_${event.id}", time.toString()).apply()
    }
    fun actual(context: Context, event: PlanEvent): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("actual_${event.id}", "") ?: ""
    fun setActual(context: Context, event: PlanEvent, text: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("actual_${event.id}", text.trim()).apply()
    }
    fun done(context: Context, event: PlanEvent): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("done_${event.id}", false)
    fun setDone(context: Context, event: PlanEvent, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("done_${event.id}", value).apply()
    }
}
