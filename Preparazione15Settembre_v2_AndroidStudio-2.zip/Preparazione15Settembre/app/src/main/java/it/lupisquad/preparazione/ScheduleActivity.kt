package it.lupisquad.preparazione

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class ScheduleActivity: AppCompatActivity() {
    private lateinit var daySpinner: Spinner
    private lateinit var list: ListView
    private val days = Plan.events.map { it.date }.distinct()
    private var currentEvents: List<PlanEvent> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_schedule)
        daySpinner=findViewById(R.id.daySpinner)
        list=findViewById(R.id.listSchedule)
        val fmt=DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.ITALIAN)
        daySpinner.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, days.map { it.format(fmt).replaceFirstChar { c -> c.uppercase() } })
        val wanted=intent.getStringExtra("date")?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: LocalDate.now()
        val idx=days.indexOfFirst { it==wanted }.let { if(it<0) 0 else it }
        daySpinner.setSelection(idx)
        daySpinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){}
            override fun onItemSelected(parent:AdapterView<*>?, view:View?, position:Int, id:Long){ showDay(days[position]) }
        }
        list.setOnItemClickListener { _,_,position,_ -> editEvent(currentEvents[position]) }
    }

    private fun showDay(day:LocalDate){
        currentEvents=Plan.events.filter { it.date==day }.sortedBy { PlanStore.time(this,it) }
        list.adapter=object:BaseAdapter(){
            override fun getCount()=currentEvents.size
            override fun getItem(p:Int)=currentEvents[p]
            override fun getItemId(p:Int)=currentEvents[p].id.toLong()
            override fun getView(p:Int, cv:View?, parent:ViewGroup?):View{
                val tv=(cv as? TextView) ?: TextView(this@ScheduleActivity).apply { setPadding(24,20,24,20); textSize=16f; setBackgroundResource(R.drawable.card_bg) }
                val e=currentEvents[p]; val t=PlanStore.time(this@ScheduleActivity,e); val actual=PlanStore.actual(this@ScheduleActivity,e); val done=PlanStore.done(this@ScheduleActivity,e)
                tv.text="${if(done) "✓ " else ""}${t}  ·  ${e.title}\n${e.body}" + if(actual.isNotBlank()) "\n\nDIARIO: $actual" else ""
                return tv
            }
        }
    }

    private fun editEvent(e:PlanEvent){
        val actual=EditText(this).apply { hint="Scrivi cosa hai realmente mangiato/fatto…"; setText(PlanStore.actual(this@ScheduleActivity,e)); minLines=3 }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(48,8,48,0); addView(actual) }
        AlertDialog.Builder(this).setTitle(e.title).setMessage(e.body).setView(box)
            .setPositiveButton("SALVA DIARIO") { _,_-> PlanStore.setActual(this,e,actual.text.toString()); showDay(e.date) }
            .setNeutralButton("MODIFICA ORA") { _,_-> pickTime(e) }
            .setNegativeButton(if(PlanStore.done(this,e)) "SEGNA DA FARE" else "SEGNA FATTO") { _,_-> PlanStore.setDone(this,e,!PlanStore.done(this,e)); AlarmScheduler.scheduleAll(this); showDay(e.date) }
            .create().apply {
                setOnShowListener {
                    if(e.video!=null) {
                        val b=Button(this@ScheduleActivity).apply { text="GUARDA VIDEO ESERCIZI"; setOnClickListener { startActivity(Intent(this@ScheduleActivity,VideoActivity::class.java).putExtra("video",e.video)) } }
                        box.addView(b)
                    }
                }
            }.show()
    }

    private fun pickTime(e:PlanEvent){
        val old=PlanStore.time(this,e)
        TimePickerDialog(this,{_,h,m-> PlanStore.setTime(this,e,java.time.LocalTime.of(h,m)); AlarmScheduler.scheduleAll(this); showDay(e.date) },old.hour,old.minute,true).show()
    }
}
