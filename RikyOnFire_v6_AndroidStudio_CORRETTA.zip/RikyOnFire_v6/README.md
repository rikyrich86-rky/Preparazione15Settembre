# Riky on fire — v5.0

Versione grafica premium ispirata al rendering approvato: tema scuro cinematico, accento arancione, hero illustrati, card compatte, selettore giorni, barra navigazione ridisegnata, schermate Programma/Video/Diario/Statistiche più curate.

Funzioni della v4 mantenute: programma 6–15 settembre, notifiche, acqua, lavoro PC, lavoro pomeridiano, pasti, allenamenti, integratori, modifica attività, stati fatto/da fare/non fatto, diario e statistiche.

I vecchi video a omino-linea sono stati sostituiti da guide visive con atleta illustrato derivate dal rendering approvato.

Versione Android: 5.0 — versionCode 5.
