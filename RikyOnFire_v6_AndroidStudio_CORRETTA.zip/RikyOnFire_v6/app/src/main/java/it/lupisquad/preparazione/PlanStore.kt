package it.lupisquad.preparazione

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

object PlanStore {
    private const val PREFS = "plan_v3"
    private fun p(context:Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun status(context:Context, event:PlanEvent):EventStatus = runCatching {
        EventStatus.valueOf(p(context).getString("status_${event.id}", EventStatus.PENDING.name)!!)
    }.getOrDefault(EventStatus.PENDING)
    fun setStatus(context:Context,event:PlanEvent,status:EventStatus){ p(context).edit().putString("status_${event.id}",status.name).apply() }

    fun start(context:Context,event:PlanEvent):LocalTime = runCatching { LocalTime.parse(p(context).getString("start_${event.id}",null) ?: event.start.toString()) }.getOrDefault(event.start)
    fun end(context:Context,event:PlanEvent):LocalTime = runCatching { LocalTime.parse(p(context).getString("end_${event.id}",null) ?: event.end.toString()) }.getOrDefault(event.end)
    fun setTimes(context:Context,event:PlanEvent,start:LocalTime,end:LocalTime){ p(context).edit().putString("start_${event.id}",start.toString()).putString("end_${event.id}",end.toString()).apply() }

    fun actual(context:Context,event:PlanEvent):String = p(context).getString("actual_${event.id}","") ?: ""
    fun setActual(context:Context,event:PlanEvent,text:String){ p(context).edit().putString("actual_${event.id}",text.trim()).apply() }
    fun note(context:Context,event:PlanEvent):String = p(context).getString("note_${event.id}","") ?: ""
    fun setNote(context:Context,event:PlanEvent,text:String){ p(context).edit().putString("note_${event.id}",text.trim()).apply() }

    fun hidden(context:Context,id:Int):Boolean = p(context).getBoolean("hidden_$id",false)
    fun hide(context:Context,event:PlanEvent){ p(context).edit().putBoolean("hidden_${event.id}",true).apply() }

    fun dayNote(context:Context,date:LocalDate):String = p(context).getString("daynote_$date","") ?: ""
    fun setDayNote(context:Context,date:LocalDate,text:String){ p(context).edit().putString("daynote_$date",text.trim()).apply() }

    fun addCustom(context:Context,event:PlanEvent){
        val arr = customArray(context)
        arr.put(toJson(event))
        p(context).edit().putString("custom_events",arr.toString()).apply()
    }
    fun deleteCustom(context:Context,id:Int){
        val old=customArray(context); val out=JSONArray()
        for(i in 0 until old.length()) if(old.optJSONObject(i)?.optInt("id")!=id) out.put(old.getJSONObject(i))
        p(context).edit().putString("custom_events",out.toString()).apply()
    }
    fun customEvents(context:Context):List<PlanEvent>{
        val arr=customArray(context); val out=mutableListOf<PlanEvent>()
        for(i in 0 until arr.length()) runCatching { out += fromJson(arr.getJSONObject(i)) }
        return out
    }
    fun reset(context:Context){ p(context).edit().clear().apply() }

    private fun customArray(context:Context)=runCatching { JSONArray(p(context).getString("custom_events","[]")) }.getOrElse { JSONArray() }
    private fun toJson(e:PlanEvent)=JSONObject().apply {
        put("id",e.id); put("date",e.date.toString()); put("start",e.start.toString()); put("end",e.end.toString()); put("title",e.title); put("body",e.body); put("type",e.type.name)
    }
    private fun fromJson(o:JSONObject)=PlanEvent(
        o.getInt("id"),LocalDate.parse(o.getString("date")),LocalTime.parse(o.getString("start")),LocalTime.parse(o.getString("end")),o.getString("title"),o.getString("body"),
        runCatching { EventType.valueOf(o.getString("type")) }.getOrDefault(EventType.OTHER), custom=true
    )
}

object PlanRepository {
    fun all(context:Context):List<PlanEvent> = (Plan.events + PlanStore.customEvents(context)).filterNot { PlanStore.hidden(context,it.id) }.sortedWith(compareBy({it.date},{PlanStore.start(context,it)}))
    fun forDate(context:Context,date:LocalDate)=all(context).filter { it.date==date }
    fun byId(context:Context,id:Int)=all(context).firstOrNull { it.id==id }
}
