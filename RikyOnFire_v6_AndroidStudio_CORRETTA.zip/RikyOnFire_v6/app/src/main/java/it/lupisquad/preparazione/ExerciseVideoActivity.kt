package it.lupisquad.preparazione

import android.net.Uri
import android.os.Bundle
import android.widget.MediaController
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class ExerciseVideoActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState)
        val key=intent.getStringExtra("video_key") ?: "mobility"
        val title=intent.getStringExtra("title") ?: "Esercizio"
        Ui.screen(this,title,"Video") { body ->
            val c=Ui.card(this,Ui.ORANGE,12)
            c.addView(Ui.label(this,"GUIDA ANIMATA"),Ui.lpMatch())
            c.addView(Ui.text(this,title,23f,Ui.TEXT,true),Ui.lpMatch().apply{topMargin=Ui.dp(this@ExerciseVideoActivity,4)})
            c.addView(Ui.text(this,"Movimento reale nell'animazione: osserva la sequenza completa prima di eseguirlo.",12f,Ui.MUTED),Ui.lpMatch().apply{topMargin=Ui.dp(this@ExerciseVideoActivity,4)})
            val vv=VideoView(this)
            vv.layoutParams=Ui.lpMatch().apply { height=Ui.dp(this@ExerciseVideoActivity,390) }
            val resId=resources.getIdentifier(key,"raw",packageName)
            if(resId!=0){
                vv.setVideoURI(Uri.parse("android.resource://$packageName/$resId"))
                vv.setMediaController(MediaController(this).apply{setAnchorView(vv)})
                vv.setOnPreparedListener { it.isLooping=true; vv.start() }
            }
            c.addView(vv,Ui.lpMatch().apply{topMargin=Ui.dp(this@ExerciseVideoActivity,10)})
            Ui.add(body,c,bottom=10)
            val tips=Ui.card(this,null,12)
            listOf("Movimento controllato, senza rimbalzi","Contrai addome e glutei quando serve","Respira in modo regolare","Mantieni l'allineamento indicato","Interrompi se avverti dolore").forEach {
                tips.addView(Ui.text(this,"✓  $it",13f,Ui.TEXT),Ui.lpMatch().apply{bottomMargin=Ui.dp(this@ExerciseVideoActivity,7)})
            }
            Ui.add(body,tips,bottom=20)
        }
    }
}
