package it.lupisquad.preparazione

import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

object EventViews {
    fun row(a:AppCompatActivity, event:PlanEvent, refresh:()->Unit, onDelete:(()->Unit)?=null):LinearLayout {
        val status=PlanStore.status(a,event)
        val accent=Ui.colorFor(event.type)
        val card=Ui.card(a, if(status==EventStatus.PENDING) Ui.BORDER else accent, 11)
        val main=Ui.horizontal(a)
        val badge=Ui.iconBadge(a,Ui.iconFor(event.type),accent,38)
        main.addView(badge,LinearLayout.LayoutParams(Ui.dp(a,38),Ui.dp(a,38)).apply{marginEnd=Ui.dp(a,10)})
        val left=Ui.vertical(a)
        val titleRow=Ui.horizontal(a)
        titleRow.addView(Ui.text(a,PlanStore.start(a,event).toString(),12f,accent,true),LinearLayout.LayoutParams(Ui.dp(a,48),-2))
        titleRow.addView(Ui.text(a,event.title,15.5f,Ui.TEXT,true),LinearLayout.LayoutParams(0,-2,1f))
        left.addView(titleRow,Ui.lpMatch())
        val body=PlanStore.actual(a,event).ifBlank { event.body }
        left.addView(Ui.text(a,body,11.5f,Ui.MUTED).apply{maxLines=2},Ui.lpMatch().apply{topMargin=Ui.dp(a,3)})
        main.addView(left,LinearLayout.LayoutParams(0,-2,1f))
        val state=Ui.iconBadge(a,Ui.statusSymbol(status),when(status){EventStatus.DONE->Ui.GREEN;EventStatus.SKIPPED->Ui.RED;EventStatus.PENDING->Ui.MUTED},32)
        main.addView(state,LinearLayout.LayoutParams(Ui.dp(a,32),Ui.dp(a,32)).apply{marginStart=Ui.dp(a,8)})
        card.addView(main,Ui.lpMatch())

        val actions=Ui.horizontal(a).apply { gravity=Gravity.END; setPadding(0,Ui.dp(a,8),0,0) }
        fun action(symbol:String,color:Int,run:()->Unit)=Ui.button(a,symbol,Ui.CARD2,color).apply { minWidth=0; minimumWidth=0; setPadding(Ui.dp(a,9),Ui.dp(a,6),Ui.dp(a,9),Ui.dp(a,6)); setOnClickListener { run() } }
        actions.addView(action("✓",Ui.GREEN){ PlanStore.setStatus(a,event,EventStatus.DONE); AlarmScheduler.scheduleAll(a); refresh() })
        actions.addView(action("○",Ui.MUTED){ PlanStore.setStatus(a,event,EventStatus.PENDING); AlarmScheduler.scheduleAll(a); refresh() })
        actions.addView(action("✕",Ui.RED){ PlanStore.setStatus(a,event,EventStatus.SKIPPED); AlarmScheduler.scheduleAll(a); refresh() })
        actions.addView(action("✎",Ui.ORANGE){ a.startActivity(Intent(a,EditEventActivity::class.java).putExtra("event_id",event.id)) })
        if(onDelete!=null) actions.addView(action("🗑",Ui.RED){ onDelete() })
        card.addView(actions,Ui.lpMatch())
        card.setOnClickListener { a.startActivity(Intent(a,DetailActivity::class.java).putExtra("event_id",event.id)) }
        return card
    }
}
