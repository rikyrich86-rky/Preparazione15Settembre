package it.lupisquad.preparazione

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class AlarmReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent){
        val id=intent.getIntExtra("event_id",1); val event=PlanRepository.byId(context,id)
        val title=event?.title ?: intent.getStringExtra("title") ?: "È il momento"
        val body=event?.let { PlanStore.actual(context,it).ifBlank { it.body } } ?: intent.getStringExtra("body") ?: "Apri l'app per i dettagli."
        val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel="programma_v3"
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(channel,"Programma e promemoria",NotificationManager.IMPORTANCE_HIGH))
        val open=PendingIntent.getActivity(context,id,Intent(context,DetailActivity::class.java).putExtra("event_id",id),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n=NotificationCompat.Builder(context,channel).setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("È il momento: $title").setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(open).build()
        runCatching { NotificationManagerCompat.from(context).notify(id,n) }
    }
}
