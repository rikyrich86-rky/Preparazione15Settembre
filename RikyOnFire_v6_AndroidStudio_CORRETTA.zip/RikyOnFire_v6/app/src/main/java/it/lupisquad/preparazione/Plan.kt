package it.lupisquad.preparazione

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

object Plan {
    val startDate: LocalDate = LocalDate.of(2026, 9, 6)
    val targetDate: LocalDate = LocalDate.of(2026, 9, 15)

    private var id = 1000
    private fun e(d:String, s:String, e:String, title:String, body:String, type:EventType, exercises:List<Exercise> = emptyList()) =
        PlanEvent(id++, LocalDate.parse(d), LocalTime.parse(s), LocalTime.parse(e), title, body, type, exercises)

    private val fullBody = listOf(
        Exercise("Piegamenti", "4 × 12-15", "Recupero 45 s", "pushup"),
        Exercise("Squat", "4 × 15", "Recupero 45 s", "squat"),
        Exercise("Affondi", "4 × 12 per gamba", "Recupero 45 s", "lunge"),
        Exercise("Plank", "3 × 45 s", "Recupero 45 s", "plank")
    )
    private val coreCardio = listOf(
        Exercise("Crunch", "3 × 20", "Recupero 30 s", "crunch"),
        Exercise("Mountain climber", "3 × 30", "Recupero 30 s", "mountain"),
        Exercise("Plank", "3 × 45 s", "Recupero 45 s", "plank")
    )
    private val light = listOf(
        Exercise("Piegamenti", "3 × 12", "Recupero 45 s", "pushup"),
        Exercise("Mobilità", "10 min", "Movimenti controllati", "mobility")
    )

    val events: List<PlanEvent> = buildList {
        fun water(d:String) {
            listOf("07:50","10:00","12:30","15:30","18:00","20:15").forEach { t ->
                val start=LocalTime.parse(t)
                add(e(d,t,start.plusMinutes(5).toString(),"Bevi acqua","Idratati: bevi acqua con calma e regolarità.",EventType.WATER))
            }
        }

        fun weekdayBlocks(d:String) {
            add(e(d,"10:30","12:30","Lavoro al PC","Blocco di lavoro al PC · 2 ore.",EventType.WORK))
            add(e(d,"14:30","17:30","Lavoro pomeridiano","Blocco di lavoro pomeridiano.",EventType.WORK))
        }

        fun day(d:String, breakfast:String, snack1:String, lunch:String, snack2:String, dinner:String, workout:Boolean, workoutBody:String?, exercises:List<Exercise> = emptyList()) {
            val date=LocalDate.parse(d)
            val weekday=date.dayOfWeek !in listOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)

            add(e(d,if(weekday) "07:30" else "07:45",if(weekday) "07:45" else "08:00","Mobilità e risveglio","Movimenti dolci, respirazione regolare, 10-15 minuti.",EventType.MOBILITY,listOf(Exercise("Mobilità","10-15 min","Movimento controllato","mobility"))))
            add(e(d,if(weekday) "08:00" else "08:30",if(weekday) "08:20" else "08:45","Colazione",breakfast,EventType.MEAL))

            if (workout) {
                val wStart = if(weekday) LocalTime.of(9,15) else LocalTime.of(10,0)
                add(e(d,wStart.minusMinutes(45).toString(),wStart.minusMinutes(40).toString(),"L-Citrullina / L-Arginina","Promemoria pre-allenamento. Segui esclusivamente dose e indicazioni riportate in etichetta o concordate con un professionista.",EventType.SUPPLEMENT))
                add(e(d,wStart.toString(),wStart.plusHours(1).toString(),"Allenamento",workoutBody ?: "Attività fisica",EventType.WORKOUT,exercises))
            } else {
                add(e(d,"08:15","08:20","L-Citrullina / L-Arginina","Giorno senza allenamento: promemoria mattutino. Segui esclusivamente dose e indicazioni riportate in etichetta o concordate con un professionista.",EventType.SUPPLEMENT))
            }

            add(e(d,if(weekday) "10:15" else "11:00",if(weekday) "10:25" else "11:10","Spuntino",snack1,EventType.MEAL))
            if(weekday) weekdayBlocks(d)
            add(e(d,if(weekday) "13:00" else "13:30",if(weekday) "13:30" else "14:00","Pranzo",lunch,EventType.MEAL))
            add(e(d,if(weekday) "17:30" else "16:30",if(weekday) "17:40" else "16:40","Spuntino",snack2,EventType.MEAL))
            add(e(d,"20:30","21:00","Cena",dinner,EventType.MEAL))
            add(e(d,"22:30","22:35","Zinco + Magnesio","Promemoria serale. Segui dose e indicazioni riportate in etichetta o concordate con medico/farmacista.",EventType.SUPPLEMENT))
            water(d)
        }

        day("2026-09-06","Yogurt greco 0% 200 g + 30 g avena + frutti di bosco.","1 mela + 5 mandorle.","Riso basmati 70 g + pollo 150 g + zucchine.","Yogurt greco 0% oppure fesa di tacchino 100 g.","Orata/spigola 200 g + finocchi e cetrioli.",true,"Full body · circa 35 min",fullBody)
        day("2026-09-07","3 albumi + 1 uovo + 2 fette pane di segale.","Banana piccola + 5 mandorle.","Pasta integrale 70 g + tonno al naturale + pomodorini.","Yogurt greco 0%.","Tacchino 180 g + asparagi.",true,"Cardio moderato · 30 min",listOf(Exercise("Camminata veloce / cyclette","30 min","Ritmo regolare","cardio")))
        day("2026-09-08","Yogurt greco 0% + frutti rossi.","1 mela.","Quinoa/riso integrale 70 g + pollo 150 g + verdure.","Fesa di tacchino 80 g.","Salmone 180 g + cetrioli e finocchi.",true,"Full body · circa 35 min",fullBody)
        day("2026-09-09","3 albumi + 1 uovo + 2 gallette di riso.","1 pera + 3 noci.","Patate 200 g + merluzzo 200 g + zucchine.","Yogurt greco 0%.","Pollo 180 g + asparagi/spinaci.",true,"Core + cardio · circa 30 min",coreCardio)
        day("2026-09-10","Yogurt greco 0% + 30 g avena + noci.","1 mela.","Riso basmati 70 g + tacchino 150 g + finocchi.","Fesa di tacchino 80 g.","Orata 200 g + cetrioli + zucchine.",true,"Full body · circa 35 min",fullBody)
        day("2026-09-11","3 albumi + 1 uovo + 2 fette pane di segale.","1 banana.","Couscous 70 g + tonno + zucchine.","Yogurt greco 0%.","Vitello magro 180 g + asparagi + insalata.",true,"Cardio moderato · 30 min",listOf(Exercise("Camminata veloce / cyclette","30 min","Ritmo regolare","cardio")))
        day("2026-09-12","Yogurt greco 0% + frutti di bosco + mandorle.","1 mela.","Riso basmati 60 g + pollo 150 g + finocchi.","Fesa di tacchino 80 g.","Pizza Margherita o Marinara semplice.",true,"Seduta leggera · circa 25 min",light)
        day("2026-09-13","3 albumi + 1 uovo + 2 gallette di riso.","1 pera.","Pollo 180 g + finocchi/cetrioli.","Yogurt greco 0%.","Merluzzo/spigola 200 g + zucchine.",false,null)
        day("2026-09-14","Yogurt greco 0% + 30 g avena.","1 mela.","Riso basmati 50 g + tacchino 150 g + asparagi.","Fesa di tacchino 80 g.","Pesce bianco 200 g oppure pollo + finocchi.",false,null)
        day("2026-09-15","Yogurt greco 0% + pochi frutti di bosco.","Mandorle.","Riso basmati 50 g + pollo 150 g + zucchine.","1 mela oppure yogurt proteico.","Pasto leggero e idratazione regolare.",false,null)
    }.sortedWith(compareBy({it.date},{it.start},{it.id}))
}
