package it.lupisquad.preparazione

import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalTime

class EditEventActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); val id=intent.getIntExtra("event_id",-1); val e=PlanRepository.byId(this,id) ?: run { finish(); return }
        Ui.screen(this,"Modifica ${e.title}","Programma") { body ->
            var start=PlanStore.start(this,e); var end=PlanStore.end(this,e)
            val startBtn=Ui.button(this,"Ora inizio: $start",Ui.CARD2,Ui.TEXT); val endBtn=Ui.button(this,"Ora fine: $end",Ui.CARD2,Ui.TEXT)
            startBtn.setOnClickListener { TimePickerDialog(this,{_,h,m-> start=LocalTime.of(h,m); startBtn.text="Ora inizio: $start"},start.hour,start.minute,true).show() }
            endBtn.setOnClickListener { TimePickerDialog(this,{_,h,m-> end=LocalTime.of(h,m); endBtn.text="Ora fine: $end"},end.hour,end.minute,true).show() }
            val actual=EditText(this).apply { hint="Attività svolta / cosa hai realmente mangiato"; setText(PlanStore.actual(this@EditEventActivity,e).ifBlank{e.body}); setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED); minLines=4; background=Ui.bg(Ui.CARD2,16,Ui.BORDER); setPadding(Ui.dp(this@EditEventActivity,12),Ui.dp(this@EditEventActivity,12),Ui.dp(this@EditEventActivity,12),Ui.dp(this@EditEventActivity,12)) }
            val note=EditText(this).apply { hint="Note personali"; setText(PlanStore.note(this@EditEventActivity,e)); setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED); minLines=3; background=Ui.bg(Ui.CARD2,16,Ui.BORDER); setPadding(Ui.dp(this@EditEventActivity,12),Ui.dp(this@EditEventActivity,12),Ui.dp(this@EditEventActivity,12),Ui.dp(this@EditEventActivity,12)) }
            Ui.add(body,startBtn,bottom=8); Ui.add(body,endBtn,bottom=12); Ui.add(body,actual,bottom=12); Ui.add(body,note,bottom=12)
            val save=Ui.button(this,"SALVA MODIFICHE"); save.setOnClickListener { if(end.isBefore(start)) end=start.plusMinutes(15); PlanStore.setTimes(this,e,start,end); PlanStore.setActual(this,e,actual.text.toString()); PlanStore.setNote(this,e,note.text.toString()); AlarmScheduler.scheduleAll(this); finish() }; Ui.add(body,save,bottom=20)
        }
    }
}
