package it.lupisquad.preparazione

import java.time.LocalDate
import java.time.LocalTime

enum class EventStatus { PENDING, DONE, SKIPPED }
enum class EventType { MEAL, WORKOUT, MOBILITY, SUPPLEMENT, WATER, WORK, SLEEP, OTHER }

data class Exercise(
    val name: String,
    val prescription: String,
    val rest: String = "",
    val videoKey: String
)

data class PlanEvent(
    val id: Int,
    val date: LocalDate,
    val start: LocalTime,
    val end: LocalTime,
    val title: String,
    val body: String,
    val type: EventType,
    val exercises: List<Exercise> = emptyList(),
    val custom: Boolean = false
)
