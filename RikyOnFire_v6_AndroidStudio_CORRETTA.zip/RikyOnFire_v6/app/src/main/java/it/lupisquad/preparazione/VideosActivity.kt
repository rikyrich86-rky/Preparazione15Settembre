package it.lupisquad.preparazione

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class VideosActivity:AppCompatActivity(){
    private var category="Tutti"
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); render() }
    private fun render(){ Ui.screen(this,"Video esercizi","Video") { body ->
        val chips=Ui.horizontal(this)
        listOf("Tutti","Forza","Core","Mobilità","Cardio").forEach { s ->
            val chip=Ui.chip(this,s,s==category).apply { setOnClickListener { category=s; render() } }
            chips.addView(chip,LinearLayout.LayoutParams(0,-2,1f).apply{marginEnd=Ui.dp(this@VideosActivity,4)})
        }
        Ui.add(body,chips,bottom=12)
        val videos=listOf(
            VideoItem("Piegamenti","Tecnica e varianti","pushup","Forza"),
            VideoItem("Squat","Controllo e profondità","squat","Forza"),
            VideoItem("Affondi","Stabilità e ritorno","lunge","Forza"),
            VideoItem("Plank","Allineamento e tenuta","plank","Core"),
            VideoItem("Crunch","Flessione controllata","crunch","Core"),
            VideoItem("Mountain climber","Ritmo e appoggio","mountain","Cardio"),
            VideoItem("Cardio","Ritmo regolare","cardio","Cardio"),
            VideoItem("Mobilità","Risveglio articolare","mobility","Mobilità")
        ).filter { category=="Tutti" || it.category==category }
        videos.forEach { v ->
            val c=Ui.card(this,null,8); val row=Ui.horizontal(this)
            val img=Ui.image(this,"thumb_${v.key}",70)
            row.addView(img,LinearLayout.LayoutParams(Ui.dp(this,104),Ui.dp(this,70)).apply{marginEnd=Ui.dp(this@VideosActivity,10)})
            val info=Ui.vertical(this)
            info.addView(Ui.text(this,v.name,15f,Ui.TEXT,true),Ui.lpMatch())
            info.addView(Ui.text(this,v.sub,11.5f,Ui.MUTED),Ui.lpMatch())
            info.addView(Ui.text(this,"GUIDA ANIMATA",9.5f,Ui.ORANGE,true),Ui.lpMatch().apply{topMargin=Ui.dp(this@VideosActivity,3)})
            row.addView(info,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(Ui.text(this,"▶",21f,Ui.ORANGE,true),LinearLayout.LayoutParams(Ui.dp(this,36),-2))
            c.addView(row,Ui.lpMatch())
            c.setOnClickListener { startActivity(Intent(this,ExerciseVideoActivity::class.java).putExtra("video_key",v.key).putExtra("title",v.name)) }
            Ui.add(body,c,bottom=7)
        }
    } }
    data class VideoItem(val name:String,val sub:String,val key:String,val category:String)
}
