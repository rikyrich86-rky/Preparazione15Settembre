package it.lupisquad.preparazione

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MoreActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); render() }
    private fun render(){ Ui.screen(this,"Altro","Altro") { body ->
        fun item(title:String,sub:String,run:()->Unit){ val c=Ui.card(this,null,12); c.addView(Ui.text(this,title,17f,Ui.TEXT,true),Ui.lpMatch()); c.addView(Ui.text(this,sub,13f,Ui.MUTED),Ui.lpMatch()); c.setOnClickListener{run()}; Ui.add(body,c,bottom=8) }
        item("🔔 Aggiorna notifiche","Ripianifica gli avvisi in base agli orari modificati."){ AlarmScheduler.scheduleAll(this); Toast.makeText(this,"Notifiche aggiornate",Toast.LENGTH_SHORT).show() }
        item("🔋 Batteria Samsung","Apri le impostazioni per consentire il funzionamento in background."){ startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        item("🎯 Obiettivo","15 settembre 2026 · progressione dal 6 al 15 settembre."){ }
        item("ℹ️ Informazioni","Riky on fire · versione 6.0"){ AlertDialog.Builder(this).setTitle("Riky on fire").setMessage("Programma personale con attività, diario, notifiche e video esercizi.\n\nVersione 6.0").setPositiveButton("OK",null).show() }
        item("🗑️ Azzera diario e modifiche","Ripristina stati, orari, note e attività personalizzate."){ AlertDialog.Builder(this).setTitle("Azzera dati?").setMessage("Questa operazione cancella tutte le modifiche personali.").setPositiveButton("Azzera"){_,_-> PlanStore.reset(this); AlarmScheduler.scheduleAll(this); Toast.makeText(this,"Dati ripristinati",Toast.LENGTH_SHORT).show() }.setNegativeButton("Annulla",null).show() }
    } }
}
