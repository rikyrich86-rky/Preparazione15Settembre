package it.lupisquad.preparazione

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDateTime
import java.time.ZoneId

object AlarmScheduler {
    fun cancel(context:Context,e:PlanEvent){
        val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(context,e))
    }

    fun scheduleAll(context:Context){
        val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        PlanRepository.all(context).forEach { e ->
            val pi=pending(context,e)
            am.cancel(pi)
            if(PlanStore.status(context,e)!=EventStatus.PENDING) return@forEach
            val whenAt=LocalDateTime.of(e.date,PlanStore.start(context,e))
            if(whenAt.isBefore(LocalDateTime.now())) return@forEach
            val millis=whenAt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi)
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi)
        }
    }
    private fun pending(context:Context,e:PlanEvent):PendingIntent {
        val i=Intent(context,AlarmReceiver::class.java).putExtra("event_id",e.id).putExtra("title",e.title).putExtra("body",e.body)
        return PendingIntent.getBroadcast(context,e.id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
