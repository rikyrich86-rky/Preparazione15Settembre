package it.lupisquad.preparazione

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

class MainActivity:AppCompatActivity(){
    private var selectedDate:LocalDate = LocalDate.now().let { when { it<Plan.startDate->Plan.startDate; it>Plan.targetDate->Plan.targetDate; else->it } }

    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState)
        selectedDate=savedInstanceState?.getString("date")?.let(LocalDate::parse) ?: selectedDate
        requestAlarms(); AlarmScheduler.scheduleAll(this); render()
    }
    override fun onSaveInstanceState(outState:Bundle){ outState.putString("date",selectedDate.toString()); super.onSaveInstanceState(outState) }
    override fun onResume(){ super.onResume(); render() }

    private fun requestAlarms(){
        if(Build.VERSION.SDK_INT>=33 && ActivityCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),10)
        if(Build.VERSION.SDK_INT>=31){ val am=getSystemService(ALARM_SERVICE) as AlarmManager; if(!am.canScheduleExactAlarms()) runCatching { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } }
    }

    private fun render(){ Ui.screen(this,"RIKY ON FIRE","Home") { body ->
        val hero=FrameLayout(this).apply { background=Ui.bg(Ui.CARD2,20,Ui.BORDER); clipToOutline=true }
        val image=Ui.image(this,"hero_home",235); hero.addView(image,FrameLayout.LayoutParams(-1,Ui.dp(this,235)))
        val shade=android.view.View(this).apply {
            background=android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(Color.argb(225,3,10,14),Color.argb(145,3,10,14),Color.argb(30,3,10,14)))
        }
        hero.addView(shade,FrameLayout.LayoutParams(-1,Ui.dp(this,235)))
        val copy=Ui.vertical(this,16).apply { gravity=Gravity.BOTTOM }
        copy.addView(Ui.text(this,"RISVEGLIA IL TUO FISICO",12f,Ui.ORANGE,true),Ui.lpMatch())
        copy.addView(Ui.text(this,"OGNI GIORNO\nUNA VERSIONE MIGLIORE DI TE",22f,Ui.TEXT,true),Ui.lpMatch())
        copy.addView(Ui.text(this,"DISCIPLINA OGGI · RISULTATI DOMANI",10.5f,Ui.MUTED,true),Ui.lpMatch().apply{topMargin=Ui.dp(this@MainActivity,8)})
        hero.addView(copy,FrameLayout.LayoutParams(Ui.dp(this,250),-1,Gravity.START or Gravity.BOTTOM))
        Ui.add(body,hero,bottom=10)

        val today=LocalDate.now(); val total=ChronoUnit.DAYS.between(Plan.startDate,Plan.targetDate).toInt()+1
        val left=when { today<Plan.startDate->ChronoUnit.DAYS.between(today,Plan.startDate).toInt(); else->maxOf(0,ChronoUnit.DAYS.between(today,Plan.targetDate).toInt()) }
        val progress=(ChronoUnit.DAYS.between(Plan.startDate,today).toInt()+1).coerceIn(0,total)
        val countdown=Ui.card(this,Ui.ORANGE,14).apply{background=Ui.bg(Color.rgb(18,24,26),18,Ui.ORANGE)}
        val cRow=Ui.horizontal(this)
        val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=total; this.progress=progress; progressTintList=android.content.res.ColorStateList.valueOf(Ui.ORANGE); rotation=270f }
        cRow.addView(bar,LinearLayout.LayoutParams(Ui.dp(this,62),Ui.dp(this,62)))
        val cText=Ui.vertical(this)
        cText.addView(Ui.label(this,if(today<Plan.startDate) "INIZIA TRA" else "MANCANO"),Ui.lpMatch())
        cText.addView(Ui.text(this,"$left ${if(left==1) "GIORNO" else "GIORNI"}",27f,Ui.ORANGE,true),Ui.lpMatch())
        cText.addView(Ui.text(this,"6 SET  →  15 SET",11f,Ui.MUTED,true),Ui.lpMatch())
        cRow.addView(cText,LinearLayout.LayoutParams(0,-2,1f))
        cRow.addView(Ui.text(this,"▣",24f,Ui.TEXT,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,54)))
        countdown.addView(cRow,Ui.lpMatch())
        countdown.addView(Ui.spacer(this,8)); countdown.addView(Ui.text(this,"▣  ${selectedDate.dayOfWeek.name.take(3)} ${selectedDate.dayOfMonth} SETTEMBRE",13f,Ui.TEXT,true),Ui.lpMatch())
        Ui.add(body,countdown,bottom=10)

        val quote=Ui.card(this,Ui.ORANGE,12).apply { background=Ui.bg(Color.rgb(45,24,13),16,Ui.ORANGE) }
        val q=Ui.horizontal(this); q.addView(Ui.text(this,"🔥",25f),LinearLayout.LayoutParams(Ui.dp(this,42),-2)); q.addView(Ui.text(this,"COSTANZA OGGI,\nRISULTATI DOMANI.",14f,Ui.TEXT,true),LinearLayout.LayoutParams(0,-2,1f)); q.addView(Ui.text(this,"›",26f,Ui.ORANGE,true),LinearLayout.LayoutParams(-2,-2)); quote.addView(q,Ui.lpMatch())
        Ui.add(body,quote,bottom=10)

        Ui.add(body,Ui.daySelector(this,selectedDate){ selectedDate=it.coerceIn(Plan.startDate,Plan.targetDate); render() },bottom=12)

        val now=LocalDateTime.now()
        val next=PlanRepository.all(this).filter { PlanStore.status(this,it)==EventStatus.PENDING }.map { it to LocalDateTime.of(it.date,PlanStore.start(this,it)) }.firstOrNull { it.second.isAfter(now) }
        if(next!=null){ val (e,whenAt)=next
            val mins=Duration.between(now,whenAt).toMinutes().coerceAtLeast(0)
            val c=Ui.card(this,Ui.ORANGE,13).apply { background=Ui.bg(Color.rgb(35,21,12),18,Ui.ORANGE) }
            c.addView(Ui.label(this,"PROSSIMA ATTIVITÀ"),Ui.lpMatch())
            val nr=Ui.horizontal(this); nr.addView(Ui.iconBadge(this,Ui.iconFor(e.type),Ui.colorFor(e.type),42),LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42)).apply{marginEnd=Ui.dp(this@MainActivity,10)}); val nt=Ui.vertical(this); nt.addView(Ui.text(this,e.title,21f,Ui.TEXT,true),Ui.lpMatch()); nt.addView(Ui.text(this,"${PlanStore.start(this,e)} · tra ${mins/60} h ${mins%60} min",13f,Ui.ORANGE,true),Ui.lpMatch()); nr.addView(nt,LinearLayout.LayoutParams(0,-2,1f)); c.addView(nr,Ui.lpMatch().apply{topMargin=Ui.dp(this@MainActivity,8)})
            val b=Ui.button(this,"DETTAGLI  →"); b.setOnClickListener { startActivity(Intent(this,DetailActivity::class.java).putExtra("event_id",e.id)) }; c.addView(b,Ui.lpMatch().apply{topMargin=Ui.dp(this@MainActivity,10)})
            Ui.add(body,c,bottom=12)
        }

        val waterEvents=PlanRepository.forDate(this,selectedDate).filter{it.type==EventType.WATER}; val waterDone=waterEvents.count{PlanStore.status(this,it)==EventStatus.DONE}
        val water=Ui.card(this,Ui.BLUE,12)
        val wr=Ui.horizontal(this); wr.addView(Ui.iconBadge(this,"●",Ui.BLUE,40),LinearLayout.LayoutParams(Ui.dp(this,40),Ui.dp(this,40)).apply{marginEnd=Ui.dp(this@MainActivity,10)}); val wt=Ui.vertical(this); wt.addView(Ui.label(this,"ACQUA OGGI"),Ui.lpMatch()); wt.addView(Ui.text(this,"$waterDone / ${waterEvents.size}",19f,Ui.TEXT,true),Ui.lpMatch()); wr.addView(wt,LinearLayout.LayoutParams(0,-2,1f)); repeat(waterEvents.size.coerceAtMost(6)){i->wr.addView(Ui.text(this,if(i<waterDone) "●" else "○",18f,if(i<waterDone) Ui.BLUE else Ui.MUTED,true),LinearLayout.LayoutParams(Ui.dp(this,24),-2))}; water.addView(wr,Ui.lpMatch()); Ui.add(body,water,bottom=14)

        val events=PlanRepository.forDate(this,selectedDate)
        Ui.add(body,Ui.sectionTitle(this,"PROGRAMMA DEL GIORNO","${events.size} attività"),bottom=8)
        if(events.isEmpty()) Ui.add(body,Ui.text(this,"Nessuna attività programmata per questo giorno.",15f,Ui.MUTED),bottom=8)
        events.forEach { Ui.add(body,EventViews.row(this,it){ render() },bottom=8) }
        Ui.add(body,Ui.spacer(this,8),bottom=8)
    } }
}

private fun LocalDate.coerceIn(min:LocalDate,max:LocalDate)=when { this<min->min; this>max->max; else->this }
