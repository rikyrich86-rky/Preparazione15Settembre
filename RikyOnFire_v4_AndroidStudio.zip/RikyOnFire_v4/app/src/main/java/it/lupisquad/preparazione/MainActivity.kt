package it.lupisquad.preparazione

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

class MainActivity:AppCompatActivity(){
    private var selectedDate:LocalDate = LocalDate.now().let { when { it<Plan.startDate->Plan.startDate; it>Plan.targetDate->Plan.targetDate; else->it } }

    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState)
        selectedDate=savedInstanceState?.getString("date")?.let(LocalDate::parse) ?: selectedDate
        requestAlarms(); AlarmScheduler.scheduleAll(this); render()
    }
    override fun onSaveInstanceState(outState:Bundle){ outState.putString("date",selectedDate.toString()); super.onSaveInstanceState(outState) }
    override fun onResume(){ super.onResume(); render() }

    private fun requestAlarms(){
        if(Build.VERSION.SDK_INT>=33 && ActivityCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),10)
        if(Build.VERSION.SDK_INT>=31){ val am=getSystemService(ALARM_SERVICE) as AlarmManager; if(!am.canScheduleExactAlarms()) runCatching { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } }
    }

    private fun render(){ Ui.screen(this,"RIKY ON FIRE","Home") { body ->
        val hero=Ui.card(this,Ui.ORANGE,18).apply { background=Ui.bg(Ui.CARD2,22,Ui.ORANGE) }
        hero.addView(Ui.text(this,"RISVEGLIA IL TUO FISICO",13f,Ui.ORANGE,true),Ui.lpMatch())
        hero.addView(Ui.text(this,"TRASFORMA IL TUO CORPO",29f,Ui.TEXT,true),Ui.lpMatch())
        hero.addView(Ui.text(this,"Disciplina oggi · risultati domani",14f,Ui.MUTED),Ui.lpMatch())
        val today=LocalDate.now()
        val days=maxOf(0,ChronoUnit.DAYS.between(today,Plan.targetDate).toInt())
        hero.addView(Ui.spacer(this,14)); hero.addView(Ui.text(this,if(today<Plan.startDate) "INIZIA TRA ${ChronoUnit.DAYS.between(today,Plan.startDate)} GIORNI" else "MANCANO $days GIORNI",27f,Ui.ORANGE,true),Ui.lpMatch())
        val total=ChronoUnit.DAYS.between(Plan.startDate,Plan.targetDate).toInt()+1
        val progress=(ChronoUnit.DAYS.between(Plan.startDate,today).toInt()+1).coerceIn(0,total)
        val pb=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=total; this.progress=progress; progressTintList=android.content.res.ColorStateList.valueOf(Ui.ORANGE) }
        hero.addView(pb,Ui.lpMatch()); hero.addView(Ui.text(this,"6 SET  →  15 SET",12f,Ui.MUTED),Ui.lpMatch())
        Ui.add(body,hero,bottom=12)

        if(today<Plan.startDate) Ui.add(body,Ui.text(this,"Oggi · preparati. Il programma parte domenica 6 settembre.",13f,Ui.MUTED),bottom=10)
        Ui.add(body,Ui.daySelector(this,selectedDate){ selectedDate=it.coerceIn(Plan.startDate,Plan.targetDate); render() },bottom=12)

        val now=LocalDateTime.now()
        val next=PlanRepository.all(this).filter { PlanStore.status(this,it)==EventStatus.PENDING }.map { it to LocalDateTime.of(it.date,PlanStore.start(this,it)) }.firstOrNull { it.second.isAfter(now) }
        if(next!=null){ val (e,whenAt)=next
            val mins=Duration.between(now,whenAt).toMinutes().coerceAtLeast(0)
            val c=Ui.card(this,Ui.ORANGE,14).apply { background=Ui.bg(android.graphics.Color.rgb(38,24,15),20,Ui.ORANGE) }
            c.addView(Ui.text(this,"PROSSIMA ATTIVITÀ",13f,Ui.ORANGE,true),Ui.lpMatch())
            c.addView(Ui.text(this,"${Ui.iconFor(e.type)}  ${e.title}",21f,Ui.TEXT,true),Ui.lpMatch())
            c.addView(Ui.text(this,"${PlanStore.start(this,e)} · tra ${mins/60} h ${mins%60} min",14f,Ui.ORANGE,true),Ui.lpMatch())
            val b=Ui.button(this,"DETTAGLI  ›"); b.setOnClickListener { startActivity(Intent(this,DetailActivity::class.java).putExtra("event_id",e.id)) }; c.addView(b,Ui.lpMatch())
            Ui.add(body,c,bottom=16)
        }

        val events=PlanRepository.forDate(this,selectedDate)
        val titleRow=Ui.horizontal(this); titleRow.addView(Ui.text(this,"PROGRAMMA DEL GIORNO",20f,Ui.TEXT,true),Ui.lpWeight(1f)); titleRow.addView(Ui.text(this,"${events.size} attività",13f,Ui.MUTED),LinearLayout.LayoutParams(-2,-2)); Ui.add(body,titleRow,bottom=8)
        if(events.isEmpty()) Ui.add(body,Ui.text(this,"Nessuna attività programmata per questo giorno.",15f,Ui.MUTED),bottom=8)
        events.forEach { Ui.add(body,EventViews.row(this,it){ render() },bottom=8) }

        val motivation=Ui.card(this,null,14); motivation.addView(Ui.text(this,"COSTANZA OGGI, GRANDI RISULTATI DOMANI.",16f,Ui.ORANGE,true),Ui.lpMatch()); motivation.addView(Ui.text(this,"Mens sana in corpore sano.",13f,Ui.MUTED),Ui.lpMatch()); Ui.add(body,motivation,top=8,bottom=12)
    } }
}

private fun LocalDate.coerceIn(min:LocalDate,max:LocalDate)=when { this<min->min; this>max->max; else->this }
