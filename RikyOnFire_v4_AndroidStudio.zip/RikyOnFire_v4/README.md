# Riky on fire — Android v4.0

Versione 4 dell'app di preparazione 6–15 settembre 2026.

Principali correzioni rispetto alla v3:
- nome app: Riky on fire;
- safe area superiore per status bar / foro fotocamera;
- barra di navigazione interna sopra la navigation bar Android/Samsung;
- UI dark premium più vicina al rendering approvato;
- lavoro al PC 10:30–12:30 dal lunedì al venerdì;
- lavoro pomeridiano 14:30–17:30 dal lunedì al venerdì;
- allenamenti feriali spostati nella finestra mattutina 09:15–10:15;
- 6 promemoria acqua giornalieri con notifiche Android;
- integrazione L-Citrullina/L-Arginina anche nei giorni senza allenamento;
- programma alimentare e allenamenti della v3 preservati.

Build: Android Studio / Gradle, package `it.lupisquad.preparazione`, versionCode 4, versionName 4.0.
