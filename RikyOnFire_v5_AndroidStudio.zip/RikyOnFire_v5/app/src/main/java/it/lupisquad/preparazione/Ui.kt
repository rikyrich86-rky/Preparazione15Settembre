package it.lupisquad.preparazione

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object Ui {
    val BG = Color.rgb(3,10,14)
    val CARD = Color.rgb(7,20,27)
    val CARD2 = Color.rgb(10,29,39)
    val CARD3 = Color.rgb(14,39,50)
    val ORANGE = Color.rgb(255,102,20)
    val ORANGE_DARK = Color.rgb(95,38,10)
    val GREEN = Color.rgb(43,215,120)
    val RED = Color.rgb(235,65,65)
    val BLUE = Color.rgb(45,167,255)
    val YELLOW = Color.rgb(239,180,32)
    val TEXT = Color.rgb(246,248,250)
    val MUTED = Color.rgb(164,181,192)
    val BORDER = Color.rgb(25,53,66)

    fun dp(c:Context,v:Int)=(v*c.resources.displayMetrics.density).toInt()
    fun bg(color:Int, radius:Int=18, stroke:Int?=null, strokeWidth:Int=1):GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius=dpFloat(radius); if(stroke!=null) setStroke(strokeWidth,stroke)
    }
    private fun dpFloat(v:Int)=v.toFloat()
    fun vertical(c:Context, pad:Int=0)=LinearLayout(c).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(c,pad),dp(c,pad),dp(c,pad),dp(c,pad)) }
    fun horizontal(c:Context)=LinearLayout(c).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
    fun text(c:Context, value:String, size:Float=16f, color:Int=TEXT, bold:Boolean=false)=TextView(c).apply {
        text=value; textSize=size; setTextColor(color); if(bold) setTypeface(typeface,Typeface.BOLD); includeFontPadding=false; letterSpacing=if(size>=22f) -0.015f else 0f
    }
    fun label(c:Context,value:String)=text(c,value.uppercase(),11f,ORANGE,true).apply { letterSpacing=.08f }
    fun button(c:Context, value:String, color:Int=ORANGE, textColor:Int=Color.BLACK)=Button(c).apply {
        text=value; setTextColor(textColor); textSize=14f; setTypeface(typeface,Typeface.BOLD); isAllCaps=false; background=bg(color,15); minHeight=0; minimumHeight=0; stateListAnimator=null; setPadding(dp(c,14),dp(c,12),dp(c,14),dp(c,12))
    }
    fun spacer(c:Context,h:Int)=Space(c).apply { layoutParams=LinearLayout.LayoutParams(1,dp(c,h)) }
    fun card(c:Context, stroke:Int?=BORDER, pad:Int=14)=vertical(c,pad).apply { background=bg(CARD,18,stroke) }
    fun lpMatch()=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT)
    fun lpWeight(w:Float)=LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,w)
    fun add(container:LinearLayout, view:View, top:Int=0, bottom:Int=0){ container.addView(view,lpMatch().apply { topMargin=dp(container.context,top); bottomMargin=dp(container.context,bottom) }) }

    fun iconFor(type:EventType)=when(type){
        EventType.MEAL->"●"; EventType.WORKOUT->"▶"; EventType.MOBILITY->"●"; EventType.SUPPLEMENT->"◆"; EventType.WATER->"●"; EventType.WORK->"■"; EventType.SLEEP->"●"; EventType.OTHER->"•"
    }
    fun colorFor(type:EventType)=when(type){
        EventType.MEAL->GREEN; EventType.WORKOUT->ORANGE; EventType.MOBILITY->GREEN; EventType.SUPPLEMENT->YELLOW; EventType.WATER->BLUE; EventType.WORK->MUTED; EventType.SLEEP->BLUE; EventType.OTHER->MUTED
    }
    fun statusSymbol(status:EventStatus)=when(status){ EventStatus.DONE->"✓"; EventStatus.PENDING->"○"; EventStatus.SKIPPED->"✕" }

    fun chip(c:Context, value:String, active:Boolean=false):TextView = text(c,value,12f,if(active) Color.BLACK else TEXT,true).apply {
        gravity=Gravity.CENTER; setPadding(dp(c,13),dp(c,8),dp(c,13),dp(c,8)); background=bg(if(active) ORANGE else CARD2,14,if(active) ORANGE else BORDER)
    }

    fun iconBadge(c:Context, symbol:String, color:Int, size:Int=38):TextView = text(c,symbol,17f,color,true).apply {
        gravity=Gravity.CENTER; background=bg(Color.argb(45,Color.red(color),Color.green(color),Color.blue(color)),size/2,color)
        layoutParams=LinearLayout.LayoutParams(dp(c,size),dp(c,size))
    }

    fun image(c:Context,resName:String,height:Int):ImageView = ImageView(c).apply {
        val id=resources.getIdentifier(resName,"drawable",c.packageName); if(id!=0) setImageResource(id)
        scaleType=ImageView.ScaleType.CENTER_CROP
        background=bg(CARD2,18,BORDER); clipToOutline=true
        layoutParams=LinearLayout.LayoutParams(-1,dp(c,height))
    }

    fun sectionTitle(c:Context,title:String,side:String?=null):LinearLayout = horizontal(c).apply {
        addView(text(c,title,19f,TEXT,true),lpWeight(1f)); if(side!=null) addView(text(c,side,12f,MUTED),LinearLayout.LayoutParams(-2,-2))
    }

    fun screen(activity:AppCompatActivity, title:String, active:String, bodyBuilder:(LinearLayout)->Unit){
        WindowCompat.setDecorFitsSystemWindows(activity.window,false)
        activity.window.statusBarColor=Color.TRANSPARENT
        activity.window.navigationBarColor=BG
        val root=vertical(activity).apply { setBackgroundColor(BG) }
        val scroll=ScrollView(activity).apply { isFillViewport=true; clipToPadding=false; overScrollMode=View.OVER_SCROLL_NEVER }
        val body=vertical(activity,16)
        val header=horizontal(activity)
        header.addView(text(activity,title,25f,TEXT,true),lpWeight(1f))
        if(title=="RIKY ON FIRE") header.addView(text(activity,"🔥",20f),LinearLayout.LayoutParams(-2,-2))
        add(body,header,top=6,bottom=14)
        bodyBuilder(body)
        scroll.addView(body)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(bottomNav(activity,active),LinearLayout.LayoutParams(-1,dp(activity,68)))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars=insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(0,bars.top,0,bars.bottom); insets
        }
        activity.setContentView(root); ViewCompat.requestApplyInsets(root)
    }

    fun bottomNav(a:AppCompatActivity, active:String):View {
        val bar=horizontal(a).apply { setPadding(dp(a,4),dp(a,5),dp(a,4),dp(a,5)); background=bg(Color.rgb(4,15,21),0,BORDER) }
        val items=listOf(
            Triple("⌂","Home",MainActivity::class.java), Triple("▣","Programma",ProgramActivity::class.java), Triple("▶","Video",VideosActivity::class.java), Triple("▥","Diario",DiaryActivity::class.java), Triple("•••","Altro",MoreActivity::class.java)
        )
        items.forEach { (icon,label,cls) ->
            val activeNow=label==active
            val item=vertical(a).apply { gravity=Gravity.CENTER; isClickable=true; isFocusable=true }
            item.addView(text(a,icon,17f,if(activeNow) ORANGE else MUTED,true).apply { gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,-2))
            item.addView(text(a,label,10.5f,if(activeNow) ORANGE else MUTED,activeNow).apply { gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,-2))
            item.setOnClickListener { if(a::class.java!=cls){ a.startActivity(Intent(a,cls)); a.overridePendingTransition(0,0); a.finish() } }
            bar.addView(item,LinearLayout.LayoutParams(0,-1,1f))
        }
        return bar
    }

    fun daySelector(a:AppCompatActivity,date:LocalDate,onChange:(LocalDate)->Unit):View {
        val box=vertical(a,10).apply { background=bg(CARD,18,BORDER) }
        val fmt=DateTimeFormatter.ofPattern("EEEE d MMMM",Locale.ITALIAN)
        val row=horizontal(a)
        val prev=button(a,"‹",CARD,ORANGE); val next=button(a,"›",CARD,ORANGE)
        val middle=text(a,date.format(fmt).replaceFirstChar{it.uppercase()},16f,TEXT,true).apply { gravity=Gravity.CENTER }
        prev.setOnClickListener{ onChange(date.minusDays(1)) }; next.setOnClickListener{ onChange(date.plusDays(1)) }
        row.addView(prev,LinearLayout.LayoutParams(dp(a,42),-2)); row.addView(middle,LinearLayout.LayoutParams(0,-2,1f)); row.addView(next,LinearLayout.LayoutParams(dp(a,42),-2))
        box.addView(row,lpMatch())
        val strip=horizontal(a).apply { gravity=Gravity.CENTER }
        (-2..2).forEach { off ->
            val d=date.plusDays(off.toLong()); val active=d==date
            val cell=vertical(a).apply { gravity=Gravity.CENTER; setPadding(dp(a,6),dp(a,5),dp(a,6),dp(a,5)); background=bg(if(active) ORANGE else CARD2,12,if(active) ORANGE else BORDER); setOnClickListener{onChange(d)} }
            cell.addView(text(a,d.dayOfWeek.name.take(3),9f,if(active) Color.BLACK else MUTED,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,-2))
            cell.addView(text(a,d.dayOfMonth.toString(),14f,if(active) Color.BLACK else TEXT,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,-2))
            strip.addView(cell,LinearLayout.LayoutParams(0,-2,1f).apply { marginStart=dp(a,3); marginEnd=dp(a,3) })
        }
        box.addView(strip,lpMatch().apply{topMargin=dp(a,7)})
        return box
    }
}
