package it.lupisquad.preparazione

import android.net.Uri
import android.os.Bundle
import android.widget.MediaController
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class ExerciseVideoActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState)
        val key=intent.getStringExtra("video_key") ?: "mobility"; val title=intent.getStringExtra("title") ?: "Esercizio"
        Ui.screen(this,title,"Video") { body ->
            val heroName=when(key){"pushup"->"hero_workout";"plank"->"hero_plank";"squat"->"thumb_squat";"lunge"->"thumb_lunge";"crunch"->"thumb_crunch";"mountain"->"thumb_mountain";"mobility"->"thumb_mobility";else->"hero_home"}
            Ui.add(body,Ui.image(this,heroName,205),bottom=10)
            val c=Ui.card(this,Ui.ORANGE,12)
            c.addView(Ui.label(this,"TECNICA"),Ui.lpMatch())
            c.addView(Ui.text(this,title,23f,Ui.TEXT,true),Ui.lpMatch().apply{topMargin=Ui.dp(this,4)})
            val vv=VideoView(this); vv.layoutParams=Ui.lpMatch().apply { height=Ui.dp(this@ExerciseVideoActivity,250) }
            val resId=resources.getIdentifier(key,"raw",packageName)
            if(resId!=0){ vv.setVideoURI(Uri.parse("android.resource://$packageName/$resId")); vv.setMediaController(MediaController(this).apply{setAnchorView(vv)}); vv.setOnPreparedListener { it.isLooping=true; vv.start() } }
            c.addView(vv,Ui.lpMatch().apply{topMargin=Ui.dp(this,10)})
            Ui.add(body,c,bottom=10)
            val tips=Ui.card(this,null,12)
            listOf("Corpo in linea e movimento controllato","Contrai addome e glutei","Respira in modo regolare","Non forzare articolazioni o schiena","Interrompi se avverti dolore").forEach { tips.addView(Ui.text(this,"✓  $it",13f,Ui.TEXT),Ui.lpMatch().apply{bottomMargin=Ui.dp(this@ExerciseVideoActivity,7)}) }
            Ui.add(body,tips,bottom=20)
        }
    }
}
