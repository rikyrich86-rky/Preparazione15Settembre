package it.lupisquad.preparazione

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class VideosActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); render() }
    private fun render(){ Ui.screen(this,"Video esercizi","Video") { body ->
        val chips=Ui.horizontal(this); listOf("Tutti","Forza","Core","Mobilità","Cardio").forEachIndexed{i,s->chips.addView(Ui.chip(this,s,i==0),LinearLayout.LayoutParams(0,-2,1f).apply{marginEnd=Ui.dp(this@VideosActivity,4)})}; Ui.add(body,chips,bottom=12)
        val videos=listOf(
            Triple("Piegamenti","Tecnica e varianti","pushup"), Triple("Squat","Controllo e profondità","squat"), Triple("Affondi","Stabilità e ritorno","lunge"), Triple("Plank","Allineamento e tenuta","plank"), Triple("Crunch","Flessione controllata","crunch"), Triple("Mountain climber","Ritmo e appoggio","mountain"), Triple("Cardio","Ritmo regolare","cardio"), Triple("Mobilità","Risveglio articolare","mobility")
        )
        videos.forEach { (name,sub,key) ->
            val c=Ui.card(this,null,8); val row=Ui.horizontal(this)
            val imgName=when(key){"pushup"->"hero_workout";"plank"->"hero_plank";"squat"->"thumb_squat";"lunge"->"thumb_lunge";"crunch"->"thumb_crunch";"mountain"->"thumb_mountain";"mobility"->"thumb_mobility";else->"hero_home"}
            val img=Ui.image(this,imgName,62); row.addView(img,LinearLayout.LayoutParams(Ui.dp(this,92),Ui.dp(this,62)).apply{marginEnd=Ui.dp(this@VideosActivity,10)})
            val info=Ui.vertical(this); info.addView(Ui.text(this,name,15f,Ui.TEXT,true),Ui.lpMatch()); info.addView(Ui.text(this,sub,11.5f,Ui.MUTED),Ui.lpMatch()); row.addView(info,LinearLayout.LayoutParams(0,-2,1f)); row.addView(Ui.text(this,"▶",21f,Ui.ORANGE,true),LinearLayout.LayoutParams(Ui.dp(this,36),-2)); c.addView(row,Ui.lpMatch()); c.setOnClickListener { startActivity(Intent(this,ExerciseVideoActivity::class.java).putExtra("video_key",key).putExtra("title",name)) }; Ui.add(body,c,bottom=7)
        }
    } }
}
