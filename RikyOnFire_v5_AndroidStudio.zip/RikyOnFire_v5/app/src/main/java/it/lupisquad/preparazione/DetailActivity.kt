package it.lupisquad.preparazione

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class DetailActivity:AppCompatActivity(){
    private var eventId:Int=-1
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); eventId=intent.getIntExtra("event_id",-1); render() }
    override fun onResume(){ super.onResume(); render() }
    private fun render(){ val e=PlanRepository.byId(this,eventId) ?: run { finish(); return }
        Ui.screen(this,e.title,"Home") { body ->
            val imageName=when(e.type){ EventType.WORKOUT->"hero_workout"; EventType.MEAL->"hero_meal"; EventType.MOBILITY->"thumb_mobility"; else->null }
            if(imageName!=null) Ui.add(body,Ui.image(this,imageName,210),bottom=10)
            val c=Ui.card(this,Ui.colorFor(e.type),14)
            c.addView(Ui.label(this,when(e.type){EventType.WORKOUT->"ALLENAMENTO";EventType.MEAL->"PASTO";else->"ATTIVITÀ"}),Ui.lpMatch())
            c.addView(Ui.text(this,e.title,25f,Ui.TEXT,true),Ui.lpMatch().apply{topMargin=Ui.dp(this,4)})
            c.addView(Ui.text(this,"${PlanStore.start(this,e)} — ${PlanStore.end(this,e)}",13f,Ui.colorFor(e.type),true),Ui.lpMatch().apply{topMargin=Ui.dp(this,4)})
            c.addView(Ui.text(this,PlanStore.actual(this,e).ifBlank{e.body},15f,Ui.MUTED),Ui.lpMatch().apply{topMargin=Ui.dp(this,10)})
            Ui.add(body,c,bottom=12)
            if(e.exercises.isNotEmpty()){
                Ui.add(body,Ui.sectionTitle(this,"ESERCIZI","${e.exercises.size}"),bottom=8)
                e.exercises.forEachIndexed { i,ex ->
                    val x=Ui.card(this,null,10); val row=Ui.horizontal(this)
                    row.addView(Ui.text(this,(i+1).toString(),17f,Ui.TEXT,true).apply{gravity=android.view.Gravity.CENTER; background=Ui.bg(Ui.CARD3,18,Ui.BORDER)},LinearLayout.LayoutParams(Ui.dp(this,38),Ui.dp(this,38)).apply{marginEnd=Ui.dp(this@DetailActivity,10)})
                    val info=Ui.vertical(this); info.addView(Ui.text(this,ex.name,15f,Ui.TEXT,true),Ui.lpMatch()); info.addView(Ui.text(this,"${ex.prescription}${if(ex.rest.isNotBlank()) " · ${ex.rest}" else ""}",11.5f,Ui.MUTED),Ui.lpMatch()); row.addView(info,LinearLayout.LayoutParams(0,-2,1f)); val play=Ui.button(this,"▶",Ui.CARD3,Ui.ORANGE); play.setOnClickListener { startActivity(Intent(this,ExerciseVideoActivity::class.java).putExtra("video_key",ex.videoKey).putExtra("title",ex.name)) }; row.addView(play,LinearLayout.LayoutParams(Ui.dp(this,52),-2)); x.addView(row,Ui.lpMatch()); Ui.add(body,x,bottom=7)
                }
            }
            val done=Ui.button(this,"✓  Segna come completato",Ui.ORANGE,Color.BLACK); done.setOnClickListener { PlanStore.setStatus(this,e,EventStatus.DONE); AlarmScheduler.scheduleAll(this); render() }; Ui.add(body,done,top=6,bottom=8)
            val edit=Ui.button(this,"✎  Modifica questa attività",Ui.CARD2,Ui.TEXT); edit.setOnClickListener { startActivity(Intent(this,EditEventActivity::class.java).putExtra("event_id",e.id)) }; Ui.add(body,edit,bottom=16)
            val note=PlanStore.note(this,e); if(note.isNotBlank()) Ui.add(body,Ui.text(this,"Nota: $note",13f,Ui.MUTED),bottom=12)
        }
    }
}
