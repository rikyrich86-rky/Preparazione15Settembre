package it.lupisquad.preparazione

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.LocalTime

class ProgramActivity:AppCompatActivity(){
    private var date=LocalDate.now().let { when { it<Plan.startDate->Plan.startDate; it>Plan.targetDate->Plan.targetDate; else->it } }
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); render() }
    override fun onResume(){ super.onResume(); render() }
    private fun render(){ Ui.screen(this,"Programma","Programma") { body ->
        val tabs=Ui.horizontal(this); listOf("Giornaliero","Settimanale","Tutti i giorni").forEachIndexed{i,s->tabs.addView(Ui.chip(this,s,i==0),LinearLayout.LayoutParams(0,-2,1f).apply{marginEnd=Ui.dp(this@ProgramActivity,5)})}; Ui.add(body,tabs,bottom=12)
        Ui.add(body,Ui.daySelector(this,date){ date=when { it<Plan.startDate->Plan.startDate; it>Plan.targetDate->Plan.targetDate; else->it }; render() },bottom=12)
        Ui.add(body,Ui.sectionTitle(this,"ATTIVITÀ DEL GIORNO","${PlanRepository.forDate(this,date).size}"),bottom=8)
        PlanRepository.forDate(this,date).forEach { e ->
            val row=EventViews.row(this,e){ render() }; row.setOnLongClickListener { confirmDelete(e); true }; Ui.add(body,row,bottom=8)
        }
        val add=Ui.button(this,"＋  Aggiungi attività"); add.setOnClickListener { addDialog() }; Ui.add(body,add,top=8,bottom=8)
        val copy=Ui.button(this,"▣  Copia da un altro giorno",Ui.CARD2,Ui.TEXT); Ui.add(body,copy,bottom=14)
        Ui.add(body,Ui.label(this,"MODELLI RAPIDI"),bottom=7)
        val quick=Ui.horizontal(this); listOf("Pasto","Allenamento","Mobilità","Altro").forEach{s->quick.addView(Ui.chip(this,s,false),LinearLayout.LayoutParams(0,-2,1f).apply{marginEnd=Ui.dp(this@ProgramActivity,4)})}; Ui.add(body,quick,bottom=20)
    } }
    private fun addDialog(){
        val wrap=Ui.vertical(this,16)
        val title=EditText(this).apply { hint="Titolo attività"; setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED) }
        val body=EditText(this).apply { hint="Dettagli / cosa devi fare o mangiare"; setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED); minLines=3 }
        val start=EditText(this).apply { hint="Ora inizio (HH:mm)"; setText("12:00"); setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED) }
        val end=EditText(this).apply { hint="Ora fine (HH:mm)"; setText("12:30"); setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED) }
        val spinner=Spinner(this); val labels=EventType.values().map { it.name }; spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,labels)
        listOf(title,body,start,end,spinner).forEach { wrap.addView(it,Ui.lpMatch()) }
        AlertDialog.Builder(this).setTitle("Nuova attività").setView(wrap).setPositiveButton("Aggiungi"){_,_->
            val s=runCatching{LocalTime.parse(start.text.toString().trim())}.getOrNull(); val en=runCatching{LocalTime.parse(end.text.toString().trim())}.getOrNull()
            if(title.text.isNotBlank() && s!=null && en!=null){ val id=(System.currentTimeMillis()%Int.MAX_VALUE).toInt(); PlanStore.addCustom(this,PlanEvent(id,date,s,en,title.text.toString().trim(),body.text.toString().trim(),EventType.valueOf(labels[spinner.selectedItemPosition]),custom=true)); AlarmScheduler.scheduleAll(this); render() }
        }.setNegativeButton("Annulla",null).show()
    }
    private fun confirmDelete(e:PlanEvent){ AlertDialog.Builder(this).setTitle("Rimuovere attività?").setMessage(e.title).setPositiveButton("Rimuovi"){_,_-> AlarmScheduler.cancel(this,e); if(e.custom) PlanStore.deleteCustom(this,e.id) else PlanStore.hide(this,e); AlarmScheduler.scheduleAll(this); render() }.setNegativeButton("Annulla",null).show() }
}
