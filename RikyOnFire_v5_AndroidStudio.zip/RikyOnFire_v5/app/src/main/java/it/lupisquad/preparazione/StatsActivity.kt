package it.lupisquad.preparazione

import android.widget.LinearLayout
import android.widget.ProgressBar
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class StatsActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); render() }
    private fun render(){ Ui.screen(this,"Le tue statistiche","Diario") { body ->
        val tabs=Ui.horizontal(this); listOf("Settimana","Mese","Totale").forEachIndexed{i,s->tabs.addView(Ui.chip(this,s,i==0),LinearLayout.LayoutParams(0,-2,1f).apply{marginEnd=Ui.dp(this@StatsActivity,5)})}; Ui.add(body,tabs,bottom=12)
        val all=PlanRepository.all(this); val done=all.count { PlanStore.status(this,it)==EventStatus.DONE }; val skipped=all.count { PlanStore.status(this,it)==EventStatus.SKIPPED }; val pending=all.size-done-skipped; val pct=if(all.isEmpty())0 else done*100/all.size
        val top=Ui.card(this,Ui.GREEN,14); val tr=Ui.horizontal(this); val tx=Ui.vertical(this); tx.addView(Ui.label(this,"ATTIVITÀ COMPLETATE"),Ui.lpMatch()); tx.addView(Ui.text(this,"$done / ${all.size}",27f,Ui.TEXT,true),Ui.lpMatch()); tr.addView(tx,LinearLayout.LayoutParams(0,-2,1f)); val ring=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=pct;progressTintList=android.content.res.ColorStateList.valueOf(Ui.GREEN)}; tr.addView(ring,LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,32))); top.addView(tr,Ui.lpMatch()); top.addView(Ui.text(this,"$pct% completato · continua così 🔥",12.5f,Ui.MUTED),Ui.lpMatch().apply{topMargin=Ui.dp(this,6)}); Ui.add(body,top,bottom=10)
        val row=Ui.horizontal(this)
        fun stat(v:String,l:String,color:Int):LinearLayout{ val c=Ui.card(this,color,10); c.addView(Ui.text(this,v,22f,color,true),Ui.lpMatch()); c.addView(Ui.text(this,l,11f,Ui.MUTED),Ui.lpMatch()); return c }
        row.addView(stat(done.toString(),"Fatte",Ui.GREEN),Ui.lpWeight(1f).apply{marginEnd=Ui.dp(this@StatsActivity,5)}); row.addView(stat(pending.toString(),"Da fare",Ui.ORANGE),Ui.lpWeight(1f).apply{marginEnd=Ui.dp(this@StatsActivity,5)}); row.addView(stat(skipped.toString(),"Saltate",Ui.RED),Ui.lpWeight(1f)); Ui.add(body,row,bottom=14)
        Ui.add(body,Ui.sectionTitle(this,"ANDAMENTO GIORNALIERO"),bottom=8)
        (Plan.startDate..Plan.targetDate).forEach { d -> val ev=PlanRepository.forDate(this,d); val dc=ev.count{PlanStore.status(this,it)==EventStatus.DONE}; val p=if(ev.isEmpty())0 else dc*100/ev.size; val c=Ui.card(this,null,9); val h=Ui.horizontal(this); h.addView(Ui.text(this,"${d.dayOfMonth} SET",13f,Ui.TEXT,true),LinearLayout.LayoutParams(Ui.dp(this,55),-2)); val pb=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=p;progressTintList=android.content.res.ColorStateList.valueOf(Ui.ORANGE)}; h.addView(pb,LinearLayout.LayoutParams(0,Ui.dp(this,16),1f)); h.addView(Ui.text(this,"$dc/${ev.size}",12f,Ui.MUTED,true),LinearLayout.LayoutParams(Ui.dp(this,48),-2)); c.addView(h,Ui.lpMatch()); Ui.add(body,c,bottom=6) }
    } }
}
private operator fun java.time.LocalDate.rangeTo(other:java.time.LocalDate):Iterable<java.time.LocalDate> = object:Iterable<java.time.LocalDate>{ override fun iterator():Iterator<java.time.LocalDate> = generateSequence(this@rangeTo){ if(it<other) it.plusDays(1) else null }.iterator() }
